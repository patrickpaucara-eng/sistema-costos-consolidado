Attribute VB_Name = "ventanas"
' ============================================================================
' VENTANAS ESTÁNDAR (DBD pp. 24-28): Menú -> Masiva -> Detalle -> Resumen.
' Una sola ventana (frmApp) cambia de contenido. Todo se dibuja desde la
' configuración: mismo marco, misma botonera (Aceptar = Enter, Cancelar = Esc)
' y mensajes del catálogo MENSAJE.
' ============================================================================
Option Explicit
Private F As Object
Private botones As Collection
Private gTrx As String, gFuente As String, gModo As String, gTabla As String, gFilaEd As Long, gObj As String
Private gExpL() As String, gExpV() As String, gExpN As Long
Private Const ANCHO As Single = 600, ALTO As Single = 400

' ---------------- arranque
Public Sub Iniciar(ByVal frm As Object)
    Set F = frm
    RecuperarPendientes      ' si Excel se cerró con una transacción en espera, se revierte al abrir
    F.Width = ANCHO + 12: F.Height = ALTO + 30
    Menu
End Sub
Public Sub AbrirApp()
    On Error GoTo SinForm
    VBA.UserForms.Add("frmApp").Show
    Exit Sub
SinForm:
    MsgBox "Ejecute primero la macro Instalar (Alt+F8).", vbExclamation, "Sistema de costos"
End Sub

' ---------------- piezas del marco estándar
Private Sub Limpiar(ByVal titulo As String)
    Dim i As Long
    For i = F.Controls.Count - 1 To 0 Step -1
        F.Controls.Remove F.Controls(i).Name
    Next i
    Set botones = New Collection
    F.Caption = "Sistema de costos - " & titulo
    Etiqueta "lblTitulo", titulo, 12, 8, 400, 18, True, 12
    Etiqueta "lblUsuario", "Usuario: " & IIf(gUsuario = "", "(sin ingresar)", gUsuario & "  /  " & gPerfil), 380, 10, 210, 14, False, 8
    Etiqueta "lblMsg", "", 12, ALTO - 30, 360, 22, False, 9
End Sub
Private Function Etiqueta(ByVal n As String, ByVal t As String, ByVal x As Single, ByVal y As Single, ByVal w As Single, ByVal h As Single, ByVal negrita As Boolean, ByVal tam As Single) As Object
    Dim c As Object
    Set c = F.Controls.Add("Forms.Label.1", n)
    c.Caption = t: c.Left = x: c.Top = y: c.Width = w: c.Height = h
    c.Font.Bold = negrita: c.Font.Size = tam
    Set Etiqueta = c
End Function
Private Function Caja(ByVal n As String, ByVal x As Single, ByVal y As Single, ByVal w As Single, ByVal valor As String) As Object
    Dim c As Object
    Set c = F.Controls.Add("Forms.TextBox.1", n)
    c.Left = x: c.Top = y: c.Width = w: c.Height = 18: c.Text = valor
    Set Caja = c
End Function
Private Function Lista(ByVal n As String, ByVal x As Single, ByVal y As Single, ByVal w As Single, ByVal fuente As String, ByVal valor As String) As Object
    Dim c As Object, p As Long, sh As String, col As String, r As Long, v As String, ya As String
    Set c = F.Controls.Add("Forms.ComboBox.1", n)
    c.Left = x: c.Top = y: c.Width = w: c.Height = 18
    p = InStr(fuente, ".")
    If p > 0 Then
        sh = Left(fuente, p - 1): col = Mid(fuente, p + 1)
        For r = 2 To UltFila(sh)
            v = CStr(Hoja(sh).Cells(r, ColIdx(sh, col)).Value)
            If InStr(ya, "|" & v & "|") = 0 Then c.AddItem v: ya = ya & "|" & v & "|"
        Next r
    End If
    If valor <> "" Then c.Value = valor Else If c.ListCount > 0 Then c.ListIndex = 0
    Set Lista = c
End Function
Private Function Boton(ByVal n As String, ByVal t As String, ByVal x As Single, ByVal y As Single, ByVal w As Single, ByVal accion As String) As Object
    Dim c As Object, b As clsBoton
    Set c = F.Controls.Add("Forms.CommandButton.1", n)
    c.Caption = t: c.Left = x: c.Top = y: c.Width = w: c.Height = 24
    Set b = New clsBoton: Set b.Btn = c: b.Accion = accion
    botones.Add b
    Set Boton = c
End Function
Private Sub Botonera(ByVal accionAceptar As String, ByVal textoAceptar As String, ByVal accionCancelar As String)
    Dim a As Object, k As Object
    If accionAceptar <> "" Then
        Set a = Boton("btnAceptar", textoAceptar, ANCHO - 200, ALTO - 34, 92, accionAceptar): a.Default = True
    End If
    Set k = Boton("btnCancelar", "Cancelar", ANCHO - 100, ALTO - 34, 92, accionCancelar): k.Cancel = True
End Sub
Private Sub Avisar(ByVal cod As String, Optional ByVal extra As String = "")
    F.Controls("lblMsg").Caption = Mensaje(cod) & IIf(extra = "", "", ": " & extra)
End Sub
Private Function Campo(ByVal n As String) As String
    Campo = CStr(F.Controls(n).Value)
End Function

' ---------------- MENÚ (árbol del diseño arquitectónico)
Public Sub Menu()
    Limpiar "Diseño arquitectónico"
    Boton "m0", "SISTEMA DE COSTOS", 230, 34, 140, "MENU"
    Boton "m1", "SEGURIDAD", 420, 34, 140, "LOGIN"
    Boton "m2", "ON-LINE", 120, 80, 140, "MENU"
    Boton "m3", "BATCH", 380, 80, 140, "MENU"
    Boton "m4", "GERENCIAL", 20, 126, 120, "MENU"
    Boton "m5", "OPERATIVO", 160, 126, 120, "MENU"
    Boton "m6", "APLICATIVO", 320, 126, 120, "MENU"
    Boton "m7", "TÉCNICO", 460, 126, 120, "MENU"
    Boton "m8", "MANT-PARM", 20, 172, 120, "MANTPARM"
    Boton "m9", "CONSULTA", 20, 204, 120, "RESUMEN"
    Boton "m10", "DATA-ENTRY", 160, 172, 120, "DATAENTRY"
    Boton "m11", "REPORTES", 160, 204, 120, "REPORTES"
    Boton "m12", "ACT-BD (cierre)", 320, 172, 120, "CIERRE"
    Boton "m13", "ESTADÍSTICAS", 320, 204, 120, "ESTADIST"
    Boton "m18", "ALERTAS", 320, 236, 120, "ALERTAS"
    Boton "m19", "REPORTES (kardex, diario)", 160, 236, 120, "REPBATCH"
    Boton "m20", "ANÁLISIS (decidir)", 460, 236, 120, "ANALISIS"
    Boton "m21", "ESTADÍSTICAS (consultar)", 320, 268, 120, "ESTCONS"
    Boton "m14", "CARGA (puerto)", 460, 172, 120, "CARGA"
    Boton "m15", "CONTINGENCIA", 460, 204, 120, "PENDIENTE"
    Boton "m17", "APROBAR (parám.)", 20, 236, 120, "APROBAR_LST"
    Boton "m16", "AUTOPRUEBA", 20, 292, 120, "AUTOPRUEBA"
    Botonera "", "", "SALIR"
    F.Controls("btnCancelar").Caption = "Salir"
End Sub

' ---------------- SEGURIDAD (Detalle)
Private Sub Login()
    Limpiar "Seguridad - ingreso"
    Etiqueta "l1", "Usuario", 150, 120, 80, 16, False, 10: Lista "C_USR", 240, 118, 160, "USUARIO.USU_COD", ""
    Etiqueta "l2", "Clave", 150, 150, 80, 16, False, 10: Caja("C_CLAVE", 240, 148, 160, "").PasswordChar = "*"
    Botonera "LOGIN_OK", "Ingresar", "MENU"
End Sub

' ---------------- MASIVA (búsqueda y selección)
Private Sub Masiva(ByVal fuente As String, ByVal titulo As String)
    Dim lb As Object
    gFuente = fuente
    Limpiar "Masiva - " & titulo
    If fuente = "REPORTES" Or fuente = "ESTADISTICAS" Or gModo = "REPORTES" Then PonerSello 350, 34, ANCHO - 362, False
    Etiqueta "l1", "Buscar:", 12, 34, 50, 16, False, 10
    Caja "C_BUSCAR", 62, 32, 200, ""
    Boton "bBuscar", "Buscar", 270, 30, 70, "BUSCAR"
    Set lb = F.Controls.Add("Forms.ListBox.1", "lstMasiva")
    lb.Left = 12: lb.Top = 60: lb.Width = ANCHO - 24: lb.Height = ALTO - 100
    Llenar ""
    Select Case fuente
        Case "TRX": Botonera "SEL_TRX", "Abrir", "MENU"
        Case "TABLAS": Botonera "SEL_TAB", "Abrir", "MENU"
        Case "REPORTES", "ESTADISTICAS": Botonera "SEL_REP", "Abrir", "MENU"
        Case "PARAM_CAMBIO"
            Boton "bRech", "Rechazar", ANCHO - 300, ALTO - 34, 92, "RECHAZAR"
            Botonera "APROBAR", "Aprobar", "MENU"
        Case "OBJETO"
            Botonera "VER_HOJA", "Ver hoja de costo", "MENU"
        Case Else
            If gTabla = fuente Then
                Boton "bNuevo", "Nuevo", ANCHO - 300, ALTO - 34, 92, "NUEVO"
                Botonera "EDITAR", "Editar", "MANTPARM"
            Else
                Botonera "", "", "MENU"
            End If
    End Select
End Sub
Private Function ModuloTrx(ByVal cod As String, ByVal modalidad As String) As String
    ' Ubicación de la transacción en la arquitectura de Tino (TRX_MODULO); por defecto, según su modalidad
    Dim t As Variant
    t = Filas("TRX_MODULO", "TMO_TRX", cod, "")
    If t(0) > 0 Then
        ModuloTrx = CStr(Hoja("TRX_MODULO").Cells(t(1), 2).Value)
    ElseIf modalidad = "ONLINE" Then
        ModuloTrx = "DATA-ENTRY"
    Else
        ModuloTrx = "ACT-BD"
    End If
End Function
Private Sub Llenar(ByVal filtro As String)
    Dim lb As Object, r As Long, j As Long, n As Long, fila As String, sh As String, fx As Variant, i As Long, t As Variant
    Set lb = F.Controls("lstMasiva"): lb.Clear
    Select Case gFuente
        Case "TRX"
            lb.ColumnCount = 3: lb.ColumnWidths = "60;360;80"
            fx = Filas("PERFIL_TRX", "PTX_PERFIL", gPerfil, "")
            For i = 1 To fx(0)
                t = Filas("TRX", "TRX_COD", Hoja("PERFIL_TRX").Cells(fx(i), 2).Value, "")
                If t(0) > 0 Then
                    r = t(1)
                    fila = Hoja("TRX").Cells(r, 1).Value & " " & Hoja("TRX").Cells(r, 2).Value
                    If ModuloTrx(CStr(Hoja("TRX").Cells(r, 1).Value), CStr(Hoja("TRX").Cells(r, 3).Value)) = gModo And (filtro = "" Or InStr(1, fila, filtro, vbTextCompare) > 0) Then
                        lb.AddItem CStr(Hoja("TRX").Cells(r, 1).Value)
                        lb.List(lb.ListCount - 1, 1) = CStr(Hoja("TRX").Cells(r, 2).Value)
                        lb.List(lb.ListCount - 1, 2) = CStr(Hoja("TRX").Cells(r, 3).Value)
                    End If
                End If
            Next i
        Case "TABLAS", "REPORTES", "ESTADISTICAS"
            lb.ColumnCount = 2: lb.ColumnWidths = "120;420"
            For r = 2 To UltFila("TABLAS_LOGICAS")
                fila = Hoja("TABLAS_LOGICAS").Cells(r, 1).Value & " " & Hoja("TABLAS_LOGICAS").Cells(r, 4).Value
                If ((gFuente = "TABLAS" And (CStr(Hoja("TABLAS_LOGICAS").Cells(r, 2).Value) = "CATÁLOGO" Or CStr(Hoja("TABLAS_LOGICAS").Cells(r, 2).Value) = "MAESTRO")) Or _
                    (gFuente = "REPORTES" And (Left(CStr(Hoja("TABLAS_LOGICAS").Cells(r, 2).Value), 6) = "PARQUE" Or CStr(Hoja("TABLAS_LOGICAS").Cells(r, 2).Value) = "HISTORICO")) Or _
                    (gFuente = "ESTADISTICAS" And InStr("|EST_CENTRO|EST_OT|EST_COMPRA|EST_DECISION|ALERTA|RENTAB|CONC_PROP|", "|" & CStr(Hoja("TABLAS_LOGICAS").Cells(r, 1).Value) & "|") > 0)) And (filtro = "" Or InStr(1, fila, filtro, vbTextCompare) > 0) Then
                    lb.AddItem CStr(Hoja("TABLAS_LOGICAS").Cells(r, 1).Value)
                    lb.List(lb.ListCount - 1, 1) = CStr(Hoja("TABLAS_LOGICAS").Cells(r, 4).Value)
                End If
            Next r
        Case Else
            sh = gFuente: n = NCols(sh): If n > 9 Then n = 9
            lb.ColumnCount = n + 1
            For r = 2 To UltFila(sh)
                fila = ""
                For j = 1 To n: fila = fila & " " & CStr(Hoja(sh).Cells(r, j).Value): Next j
                If filtro = "" Or InStr(1, fila, filtro, vbTextCompare) > 0 Then
                    lb.AddItem CStr(Hoja(sh).Cells(r, 1).Value)
                    For j = 2 To n: lb.List(lb.ListCount - 1, j - 1) = CStr(Hoja(sh).Cells(r, j).Value): Next j
                    lb.List(lb.ListCount - 1, n) = CStr(r)   ' fila de la hoja (para editar)
                End If
            Next r
    End Select
End Sub

' ---------------- DETALLE (cabecera + grilla de líneas + pie + botonera)
Private Sub Detalle(ByVal trx As String)
    Dim c As Variant, i As Long, y As Single, xl As Single, nl As Long, var As String, lb As Object, def As String
    gTrx = trx
    Limpiar "Detalle - " & trx & " " & Hoja("TRX").Cells(Filas("TRX", "TRX_COD", trx, "")(1), 2).Value
    c = Filas("TRX_CAMPO", "TCA_TRX", trx, "TCA_SEC")
    y = 34
    For i = 1 To c(0)
        If CStr(Hoja("TRX_CAMPO").Cells(c(i), 5).Value) = "C" Then
            var = CStr(Hoja("TRX_CAMPO").Cells(c(i), 3).Value)
            def = ""
            If var = "FECHA" Then def = Format(Date, "yyyymmdd")
            If var = "PER" Then def = Format(Date, "yyyy-mm")
            If var = "EMP" Then def = EmpresaUsuario()   ' la empresa del usuario: no se digita (captura en origen)
            Etiqueta "e" & var, CStr(Hoja("TRX_CAMPO").Cells(c(i), 4).Value), 12 + ((i - 1) Mod 2) * 290, y + 2, 110, 16, False, 9
            If CStr(Hoja("TRX_CAMPO").Cells(c(i), 6).Value) <> "" Then
                Lista "C_" & var, 125 + ((i - 1) Mod 2) * 290, y, 150, CStr(Hoja("TRX_CAMPO").Cells(c(i), 6).Value), def
            Else
                Caja "C_" & var, 125 + ((i - 1) Mod 2) * 290, y, 150, def
            End If
            If (i Mod 2) = 0 Then y = y + 24
        End If
    Next i
    y = y + 30: xl = 12
    For i = 1 To c(0)
        If CStr(Hoja("TRX_CAMPO").Cells(c(i), 5).Value) = "L" Then
            var = CStr(Hoja("TRX_CAMPO").Cells(c(i), 3).Value): nl = nl + 1
            Etiqueta "e" & var, CStr(Hoja("TRX_CAMPO").Cells(c(i), 4).Value), xl, y, 140, 14, False, 8
            If CStr(Hoja("TRX_CAMPO").Cells(c(i), 6).Value) <> "" Then
                Lista "L_" & var, xl, y + 14, 140, CStr(Hoja("TRX_CAMPO").Cells(c(i), 6).Value), ""
            Else
                Caja "L_" & var, xl, y + 14, 140, ""
            End If
            xl = xl + 150
        End If
    Next i
    If nl > 0 Then
        Boton "bAgregar", "+ Agregar", ANCHO - 100, y + 10, 88, "AGREGAR"
        Set lb = F.Controls.Add("Forms.ListBox.1", "lstLineas")
        lb.Left = 12: lb.Top = y + 42: lb.Width = ANCHO - 120: lb.Height = ALTO - y - 120: lb.ColumnCount = nl
        Boton "bQuitar", "- Quitar", ANCHO - 100, y + 42, 88, "QUITAR"
        Etiqueta "lblPie", "Líneas: 0", 12, ALTO - 58, 120, 16, True, 9
        Etiqueta "lScan", "Escanear (código*cantidad):", 140, ALTO - 58, 140, 16, False, 8
        Caja "C_SCAN", 280, ALTO - 60, 120, ""
    End If
    Botonera "GRABAR", "Aceptar", "MENU"
End Sub
Private Sub Agregar()
    Dim lb As Object, c As Variant, i As Long, j As Long, var As String, cod As String, p As Long
    ' lector de código de barras o QR: "CAJA4KG*120" llena recurso y cantidad sin digitar
    cod = Trim(Campo("C_SCAN"))
    If cod <> "" Then
        p = InStr(cod, "*")
        On Error Resume Next
        If p > 0 Then
            F.Controls("L_REC").Value = Left(cod, p - 1): F.Controls("L_CANT").Value = Mid(cod, p + 1)
        Else
            F.Controls("L_REC").Value = cod
        End If
        F.Controls("C_SCAN").Value = ""
        On Error GoTo 0
    End If
    Set lb = F.Controls("lstLineas")
    c = Filas("TRX_CAMPO", "TCA_TRX", gTrx, "TCA_SEC")
    For i = 1 To c(0)
        If CStr(Hoja("TRX_CAMPO").Cells(c(i), 5).Value) = "L" Then
            var = CStr(Hoja("TRX_CAMPO").Cells(c(i), 3).Value)
            If j = 0 Then lb.AddItem Campo("L_" & var) Else lb.List(lb.ListCount - 1, j) = Campo("L_" & var)
            j = j + 1
        End If
    Next i
    F.Controls("lblPie").Caption = "Líneas: " & lb.ListCount
End Sub
Private Sub Grabar()
    ' Cabecera + todas las líneas = UN evento (una transacción): si una línea falla, no se graba nada.
    Dim c As Variant, i As Long, k As Long, j As Long, var As String, res As String, nLin As Long, tieneLineas As Boolean
    Dim lin() As String, s As String
    c = Filas("TRX_CAMPO", "TCA_TRX", gTrx, "TCA_SEC")
    For i = 1 To c(0)
        If CStr(Hoja("TRX_CAMPO").Cells(c(i), 5).Value) = "L" Then tieneLineas = True
    Next i
    TReset
    For i = 1 To c(0)
        var = CStr(Hoja("TRX_CAMPO").Cells(c(i), 3).Value)
        If CStr(Hoja("TRX_CAMPO").Cells(c(i), 5).Value) = "C" Then TSet var, ParseValor(Campo("C_" & var))
    Next i
    TSet "MODO", "PREVIA"     ' arrepentimiento (DBD p. 26): se aplica, se avisa "listo" y el usuario confirma o deshace
    If Not tieneLineas Then
        res = EjecutarTRX(gTrx)
    Else
        nLin = F.Controls("lstLineas").ListCount
        If nLin = 0 Then Avisar "MSG-SINLINEAS": Exit Sub
        ReDim lin(0 To nLin - 1)
        For k = 0 To nLin - 1
            s = "": j = 0
            For i = 1 To c(0)
                If CStr(Hoja("TRX_CAMPO").Cells(c(i), 5).Value) = "L" Then
                    var = CStr(Hoja("TRX_CAMPO").Cells(c(i), 3).Value)
                    s = s & var & "=" & CStr(F.Controls("lstLineas").List(k, j)) & ";": j = j + 1
                End If
            Next i
            lin(k) = s
        Next k
        res = EjecutarTRX(gTrx, lin)
    End If
    If res = "OK" Then
        Limpiar "Listo para aplicar - " & gTrx
        Etiqueta "lL1", Mensaje("MSG-LISTO"), 20, 60, ANCHO - 40, 18, True, 11
        Etiqueta "lL2", "1 evento" & IIf(tieneLineas, " con " & nLin & " línea(s)", "") & ". Revise en REPORTES si lo desea antes de confirmar.", 20, 90, ANCHO - 40, 18, False, 9
        Botonera "CONFIRMAR", "Confirmar", "DESHACER"
    Else
        F.Controls("lblMsg").Caption = res
    End If
End Sub

' ---------------- RESUMEN (hoja de costo y capacidad)
Private Sub Resumen(ByVal obj As String)
    ' Pantalla 1 (E-086): hoja de costo del OBJETO de costo (cualquier tipo, EC-01) con su desglose, el CIF provisional
    ' (tasa predeterminada, EC-42) mientras no se cierre, el costo por centro (EC-41), la última proyección (ESTADÍSTICAS)
    ' y la regla oficial con que se calcula (EC-04). Se puede exportar con ese sello (EC-45).
    Dim r As Long, y As Single, i As Long, t(1 To 5) As Double, cols As Variant, nom As Variant, fo As Variant, tot As Double
    Dim ctrl As Variant, etq As Variant, v As String, ws As Object, k As Long, ofi As Boolean
    cols = Array("COP_MAT", "COP_MOD", "COP_IND", "COP_IND_APL", "COP_PERD")
    nom = Array("Materiales (lo permitido)", "Mano de obra directa", "Indirectos asignados al cierre (oficial)", "Indirectos provisionales (tasa predeterminada)", "Pérdida anormal (fue a gasto, no es costo)")
    For r = 2 To UltFila("CTA_OBJ_PER")
        If CStr(Hoja("CTA_OBJ_PER").Cells(r, ColIdx("CTA_OBJ_PER", "COP_OBJ")).Value) = obj Then
            For i = 1 To 5
                t(i) = t(i) + Num(Hoja("CTA_OBJ_PER").Cells(r, ColIdx("CTA_OBJ_PER", CStr(cols(i - 1)))).Value)
            Next i
        End If
    Next r
    Limpiar "Resumen - hoja de costo del objeto " & obj
    gExpN = 0: ExpAgrega "Objeto de costo", obj: ExpAgrega "Usuario", gUsuario: ExpAgrega "Fecha de emisión", Format(Now, "yyyy-mm-dd hh:nn")
    PonerSello 12, 22, 560, True
    y = 34
    For i = 1 To 5
        Etiqueta "r" & i, CStr(nom(i - 1)), 20, y, 380, 14, False, 9
        Etiqueta "v" & i, Format(t(i), "#,##0.00"), 420, y, 150, 14, False, 9
        ExpAgrega CStr(nom(i - 1)), Format(t(i), "0.00")
        y = y + 17
    Next i
    ofi = (t(3) > 0)
    tot = t(1) + t(2) + IIf(ofi, t(3), t(4))
    Etiqueta "rT", "COSTO DEL OBJETO (" & IIf(ofi, "oficial", "provisional: falta el cierre") & ")", 20, y, 380, 16, True, 10
    Etiqueta "vT", Format(tot, "#,##0.00"), 420, y, 150, 16, True, 10
    ExpAgrega "Costo del objeto (" & IIf(ofi, "oficial", "provisional") & ")", Format(tot, "0.00")
    y = y + 24
    Set ws = Hoja("CONS_CAP")
    For r = 2 To UltFila("CONS_CAP")
        If CStr(ws.Cells(r, ColIdx("CONS_CAP", "CCA_OBJ")).Value) = obj Then
            k = k + 1
            v = "Centro " & ws.Cells(r, ColIdx("CONS_CAP", "CCA_CEN")).Value & " (" & ws.Cells(r, ColIdx("CONS_CAP", "CCA_PER")).Value & "): " & Format(Num(ws.Cells(r, ColIdx("CONS_CAP", "CCA_HORAS")).Value), "#,##0.0") & " h"
            Etiqueta "cc" & k, v, 30, y, 370, 14, False, 9
            Etiqueta "cv" & k, Format(Num(ws.Cells(r, ColIdx("CONS_CAP", "CCA_CST")).Value), "#,##0.00"), 420, y, 150, 14, False, 9
            ExpAgrega v, Format(Num(ws.Cells(r, ColIdx("CONS_CAP", "CCA_CST")).Value), "0.00")
            y = y + 16
        End If
    Next r
    fo = Filas("OBJETO", "OBJ_NUM", obj, "")
    If fo(0) > 0 Then
        ctrl = Array("OBJ_TIPO", "OBJ_EST", "OBJ_AVA", "OBJ_CST_PLAN", "OBJ_PLAN_BASE", "OBJ_CST_REAL")
        etq = Array("Tipo de objeto", "Estado (A abierto, T terminado, L liquidado)", "Avance %", "Planificado congelado", "Referencia de la decisión", "Costo liquidado")
        y = y + 6
        For i = 0 To 5
            v = CStr(Hoja("OBJETO").Cells(fo(1), ColIdx("OBJETO", CStr(ctrl(i)))).Value)
            If EsNum(Hoja("OBJETO").Cells(fo(1), ColIdx("OBJETO", CStr(ctrl(i)))).Value) Then v = Format(Num(v), "#,##0.00")
            Etiqueta "c" & i, CStr(etq(i)), 20, y, 380, 14, False, 9: Etiqueta "d" & i, v, 420, y, 150, 14, False, 9
            ExpAgrega CStr(etq(i)), v
            y = y + 16
        Next i
    End If
    If ofi And t(4) > 0 Then
        Etiqueta "sa", IIf(t(4) > t(3), "CIF sobreaplicado (provisional - oficial)", "CIF subaplicado (oficial - provisional)"), 20, y, 380, 14, False, 9
        Etiqueta "sv", Format(Abs(t(4) - t(3)), "#,##0.00"), 420, y, 150, 14, False, 9
        ExpAgrega IIf(t(4) > t(3), "CIF sobreaplicado", "CIF subaplicado"), Format(Abs(t(4) - t(3)), "0.00")
        y = y + 18
    End If
    v = ""
    If fo(0) > 0 Then
        If CStr(Hoja("OBJETO").Cells(fo(1), ColIdx("OBJETO", "OBJ_EST")).Value) <> "L" Then v = UltimaProyeccion(obj)   ' EC-57: liquidado = sin proyección
    End If
    If v <> "" Then
        Etiqueta "pj", "Última proyección (ESTADÍSTICAS): " & v, 20, y, ANCHO - 40, 14, False, 9: y = y + 16
        ExpAgrega "Última proyección", v
    End If
    Etiqueta "rof", "Regla oficial: " & ReglaOficialTexto(), 20, y, ANCHO - 40, 28, False, 8
    ExpAgrega "Regla oficial con que se calculó", ReglaOficialTexto()
    gObj = obj
    Boton "bCalc", "Ver cálculo", ANCHO - 300, ALTO - 34, 92, "VER_CALC"
    Boton "bExp", "Exportar", ANCHO - 400, ALTO - 34, 92, "EXPORTAR"
    Botonera "", "", "RESUMEN"
End Sub
Private Sub PonerSello(ByVal x As Single, ByVal y As Single, ByVal w As Single, ByVal exportar As Boolean)
    ' OT-045: el sello del modo (p. ej. "COSTO REAL PROVISIONAL - PILOTO") sale de PARAMETRO MODO_SISTEMA y MENSAJE
    Dim txt As String
    txt = Sello()
    If txt = "" Then Exit Sub
    Etiqueta "lSello", txt, x, y, w, 12, True, 8
    F.Controls("lSello").ForeColor = RGB(192, 0, 0)
    If exportar Then ExpAgrega "Sello", txt
End Sub
Private Sub ExpAgrega(ByVal etiq As String, ByVal dato As String)
    gExpN = gExpN + 1
    ReDim Preserve gExpL(1 To gExpN): ReDim Preserve gExpV(1 To gExpN)
    gExpL(gExpN) = etiq: gExpV(gExpN) = dato
End Sub
Private Sub AbrirAnalisis()
    ' Pantalla de análisis (E-087): página local en el navegador, servida por Python desde la carpeta del libro.
    ' Se guarda el libro antes (la pantalla lee lo guardado) y la decisión vuelve por la bandeja -> CARGA (puerto).
    Dim cmd As String
    If gUsuario = "" Then
        Avisar "MSG-SINLOGIN"
        Exit Sub
    End If
    On Error GoTo SinPython
    ThisWorkbook.Save
    If LCase(Left(ThisWorkbook.Path, 4)) = "http" Then
        F.Controls("lblMsg").Caption = "El libro está en OneDrive/SharePoint (ruta web). Cópielo a una carpeta local (p. ej. Documentos) con la carpeta algoritmos."
        Exit Sub
    End If
    If Dir(ThisWorkbook.Path & Application.PathSeparator & "abrir_analisis.bat") = "" Then
        F.Controls("lblMsg").Caption = "Falta abrir_analisis.bat junto al libro (copie el paquete completo)."
        Exit Sub
    End If
    cmd = "cmd /c """"" & ThisWorkbook.Path & Application.PathSeparator & "abrir_analisis.bat"" """ & ThisWorkbook.FullName & """ " & gUsuario & """"
    Shell cmd, 1
    F.Controls("lblMsg").Caption = "Se abre la pantalla de análisis (si hay un problema, la ventana negra lo explica)."
    Exit Sub
SinPython:
    F.Controls("lblMsg").Caption = "No se pudo iniciar Python (instale Python 3 con openpyxl y numpy)."
End Sub
Private Sub ExportarHoja()
    ' EC-45: la hoja de costo sale con la regla oficial y los parámetros con que se calculó
    Dim ws As Object, i As Long
    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets("HOJA_COSTO_EXPORT")
    On Error GoTo 0
    If ws Is Nothing Then
        Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
        ws.Name = "HOJA_COSTO_EXPORT"
    End If
    ws.Cells.ClearContents
    For i = 1 To gExpN
        ws.Cells(i, 1).Value = gExpL(i): ws.Cells(i, 2).Value = gExpV(i)
    Next i
    F.Controls("lblMsg").Caption = "Exportado a la hoja HOJA_COSTO_EXPORT (cópiela o guárdela como PDF)."
End Sub
Private Function ReglaOficialTexto() As String
    Dim r As Long, t As String
    For r = 2 To UltFila("REGLA_OFICIAL")
        t = t & IIf(t = "", "", "; ") & Hoja("REGLA_OFICIAL").Cells(r, 1).Value & " = " & Hoja("REGLA_OFICIAL").Cells(r, 2).Value
    Next r
    ReglaOficialTexto = t
End Function
Private Function UltimaProyeccion(ByVal obj As String) As String
    Dim r As Long, ws As Object
    Set ws = Hoja("EST_OT")
    For r = 2 To UltFila("EST_OT")
        If CStr(ws.Cells(r, ColIdx("EST_OT", "EOT_OBJ")).Value) = obj And CStr(ws.Cells(r, ColIdx("EST_OT", "EOT_PROY")).Value) <> "" Then
            UltimaProyeccion = Format(Num(ws.Cells(r, ColIdx("EST_OT", "EOT_PROY")).Value), "#,##0.00") & " (" & ws.Cells(r, ColIdx("EST_OT", "EOT_PER")).Value & ", " & ws.Cells(r, ColIdx("EST_OT", "EOT_MARCA")).Value & ")"
        End If
    Next r
End Function
Private Sub ResumenAlertas()
    ' Modelo Resumen (DBD p. 28): alertas por tipo y, debajo, el detalle de cada una (bajada, EC-11 / EC-38)
    Dim r As Long, tipos As Variant, i As Long, n As Long, y As Single, ws As Object, lb As Object
    tipos = Array("MARGEN", "PERDIDA", "OCIO", "DIFERENCIA", "TENDENCIA")
    Limpiar "Resumen - alertas por tipo (ESTADÍSTICAS)"
    Set ws = Hoja("ALERTA"): y = 34
    For i = 0 To 4
        n = 0
        For r = 2 To UltFila("ALERTA")
            If CStr(ws.Cells(r, ColIdx("ALERTA", "ALE_TIPO")).Value) = CStr(tipos(i)) Then n = n + 1
        Next r
        Etiqueta "a" & i, CStr(tipos(i)), 40, y, 200, 16, True, 10
        Etiqueta "n" & i, IIf(n = 0, "sin alertas", n & " alerta(s)"), 260, y, 200, 16, (n > 0), 10
        If n > 0 Then F.Controls("n" & i).ForeColor = RGB(192, 0, 0) Else F.Controls("n" & i).ForeColor = RGB(0, 128, 0)
        y = y + 20
    Next i
    Set lb = F.Controls.Add("Forms.ListBox.1", "lstAle")
    lb.Left = 20: lb.Top = y + 6: lb.Width = ANCHO - 40: lb.Height = ALTO - y - 60: lb.ColumnCount = 6: lb.ColumnWidths = "60;90;80;60;80;80"
    lb.AddItem "Periodo": lb.List(0, 1) = "Tipo": lb.List(0, 2) = "Referencia": lb.List(0, 3) = "Ref. 2": lb.List(0, 4) = "Valor": lb.List(0, 5) = "Umbral"
    For r = 2 To UltFila("ALERTA")
        lb.AddItem CStr(ws.Cells(r, 1).Value)
        For i = 1 To 5
            lb.List(lb.ListCount - 1, i) = CStr(ws.Cells(r, ColIdx("ALERTA", CStr(Array("ALE_TIPO", "ALE_REF", "ALE_REF2", "ALE_VAL", "ALE_UMB")(i - 1)))).Value)
        Next i
    Next r
    Botonera "", "", "MENU"
End Sub
Private Sub VerCalculo(ByVal obj As String)
    ' Explica el costo de la orden con los hechos guardados: cantidades reales contra permitidas, horas por tasa, diferencias.
    Dim r As Long, y As Single, n As Long, t As String, ws As Object, nt As Long
    Limpiar "Detalle - cálculo del costo del objeto " & obj
    y = 34
    Set ws = Hoja("CTA_OBJ_REC")
    For r = 2 To UltFila("CTA_OBJ_REC")
        If CStr(ws.Cells(r, ColIdx("CTA_OBJ_REC", "COR_OBJ")).Value) = obj Then
            t = CStr(ws.Cells(r, ColIdx("CTA_OBJ_REC", "COR_PER")).Value) & "  " & CStr(ws.Cells(r, ColIdx("CTA_OBJ_REC", "COR_REC")).Value) & ": real " & _
                Format(Num(ws.Cells(r, ColIdx("CTA_OBJ_REC", "COR_CAN_REAL")).Value), "#,##0.00") & " por S/ " & Format(Num(ws.Cells(r, ColIdx("CTA_OBJ_REC", "COR_MTO")).Value), "#,##0.00") & _
                "; permitido " & Format(Num(ws.Cells(r, ColIdx("CTA_OBJ_REC", "COR_CAN_PERM")).Value), "#,##0.00") & " (lo que excede va a gasto)"
            n = n + 1: Etiqueta "x" & n, t, 12, y, ANCHO - 24, 14, False, 8: y = y + 16
        End If
    Next r
    Set ws = Hoja("CONS_CAP")
    For r = 2 To UltFila("CONS_CAP")
        If CStr(ws.Cells(r, ColIdx("CONS_CAP", "CCA_OBJ")).Value) = obj Then
            t = CStr(ws.Cells(r, ColIdx("CONS_CAP", "CCA_PER")).Value) & "  " & CStr(ws.Cells(r, ColIdx("CONS_CAP", "CCA_CEN")).Value) & ": " & _
                Format(Num(ws.Cells(r, ColIdx("CONS_CAP", "CCA_HORAS")).Value), "#,##0.00") & " h efectivas × tasa del cierre = S/ " & Format(Num(ws.Cells(r, ColIdx("CONS_CAP", "CCA_CST")).Value), "#,##0.00") & _
                " (el resto de la capacidad es ocio: gasto)"
            n = n + 1: Etiqueta "x" & n, t, 12, y, ANCHO - 24, 14, False, 8: y = y + 16
        End If
    Next r
    Set ws = Hoja("DIFERENCIA")
    For r = 2 To UltFila("DIFERENCIA")
        If CStr(ws.Cells(r, ColIdx("DIFERENCIA", "DIF_OBJ")).Value) = obj Then
            t = CStr(ws.Cells(r, ColIdx("DIFERENCIA", "DIF_REC")).Value) & ": diferencia de cantidad S/ " & Format(Num(ws.Cells(r, ColIdx("DIFERENCIA", "DIF_CAN")).Value), "#,##0.00") & _
                ", de precio S/ " & Format(Num(ws.Cells(r, ColIdx("DIFERENCIA", "DIF_PRE")).Value), "#,##0.00")
            n = n + 1: Etiqueta "x" & n, t, 12, y, ANCHO - 24, 14, False, 8: y = y + 16
        End If
    Next r
    For r = 2 To UltFila("TRAZA")
        If CStr(Hoja("TRAZA").Cells(r, ColIdx("TRAZA", "TRZ_OBJ")).Value) = obj Then nt = nt + 1
    Next r
    If nt > 0 Then Boton "bTraza", "Ver traza", ANCHO - 300, ALTO - 34, 92, "VER_TRAZA"
    Etiqueta "xT", IIf(nt > 0, nt & " fórmulas anotadas en TRAZA para esta orden (REPORTES -> TRAZA).", "Para ver cada fórmula, active TRAZA = S en PARAMETRO antes de registrar."), 12, y + 8, ANCHO - 24, 14, True, 8
    Botonera "", "", "RESUMEN"
End Sub

' ---------------- MANT-PARM: edición de una fila de parámetros (Detalle) con bitácora y reversa
Private Sub EditarFila(ByVal fila As Long)
    Dim j As Long, n As Long, y As Single, x As Single, v As String
    gFilaEd = fila
    Limpiar "Detalle - " & gTabla & IIf(fila = 0, " (nuevo)", " (fila " & fila & ")")
    n = NCols(gTabla): y = 40
    For j = 1 To n
        x = 12 + ((j - 1) Mod 2) * 290
        v = "": If fila > 0 Then v = CStr(Hoja(gTabla).Cells(fila, j).Value)
        Etiqueta "e" & j, CStr(Hoja(gTabla).Cells(1, j).Value), x, y + 2, 110, 16, False, 9
        Caja "C_" & j, x + 113, y, 160, v
        If (j Mod 2) = 0 Then y = y + 24
    Next j
    Botonera "GUARDAR_PARM", "Aceptar", "VOLVER_TAB"
End Sub
Private Sub GuardarParm()
    Dim j As Long, n As Long, v() As Variant, res As String
    n = NCols(gTabla): ReDim v(1 To n)
    For j = 1 To n: v(j) = ParseValor(Campo("C_" & j)): Next j
    If DobleControl() Or EsProtegido(gTabla, gFilaEd) Then
        ' gobierno: cada cambio es una propuesta con su motivo; los cambios de una misma edición forman un paquete
        Dim motivo As String, paq As String
        motivo = InputBox("Motivo del cambio (obligatorio):", "Propuesta de cambio")
        paq = "P-" & Format(Now, "yyyymmddhhnnss") & "-" & gUsuario
        If gFilaEd = 0 Then
            Dim txt As String
            For j = 1 To n: txt = txt & IIf(j > 1, "|", "") & CStr(v(j)): Next j
            res = ProponerCambio(gTabla, v(1), "(NUEVA)", txt, motivo, paq)
        Else
            res = "OK"
            For j = 1 To n
                If res = "OK" And Norm(v(j)) <> Norm(Hoja(gTabla).Cells(gFilaEd, j).Value) Then res = ProponerCambio(gTabla, Hoja(gTabla).Cells(gFilaEd, 1).Value, CStr(Hoja(gTabla).Cells(1, j).Value), v(j), motivo, paq)
            Next j
        End If
        If res = "OK" Then
            Masiva gTabla, "Parámetros: " & gTabla: Avisar "MSG-PROPUESTA"
        Else
            F.Controls("lblMsg").Caption = res
        End If
        Exit Sub
    End If
    res = MantenerFila(gTabla, gFilaEd, v)
    If res = "OK" Then
        Masiva gTabla, "Parámetros: " & gTabla: Avisar "MSG-OK"
    Else
        F.Controls("lblMsg").Caption = res
    End If
End Sub

' ---------------- despacho de acciones (todas pasan por aquí)
Public Sub Ejecutar(ByVal accion As String)
    Dim res As String
    On Error GoTo Fallo
    Select Case accion
        Case "MENU": Menu
        Case "SALIR": Unload F
        Case "LOGIN": Login
        Case "LOGIN_OK"
            If ui.Login(UCase(Campo("C_USR")), Campo("C_CLAVE")) Then Menu Else Avisar "MSG-LOGIN"
        Case "DATAENTRY"
            If gUsuario = "" Then Avisar "MSG-SINLOGIN" Else gModo = "DATA-ENTRY": Masiva "TRX", "DATA-ENTRY: registro de hechos autorizados"
        Case "BUSCAR": Llenar Campo("C_BUSCAR")
        Case "SEL_TRX"
            If F.Controls("lstMasiva").ListIndex >= 0 Then Detalle CStr(F.Controls("lstMasiva").List(F.Controls("lstMasiva").ListIndex, 0))
        Case "AGREGAR": Agregar
        Case "QUITAR"
            If F.Controls("lstLineas").ListIndex >= 0 Then F.Controls("lstLineas").RemoveItem F.Controls("lstLineas").ListIndex
            F.Controls("lblPie").Caption = "Líneas: " & F.Controls("lstLineas").ListCount
        Case "GRABAR": Grabar
        Case "REPORTES": gTabla = "": Masiva "REPORTES", "Reportes del parque (kardex, ventas, gastos, estimaciones)"
        Case "SEL_REP"
            If F.Controls("lstMasiva").ListIndex >= 0 Then Masiva CStr(F.Controls("lstMasiva").List(F.Controls("lstMasiva").ListIndex, 0)), "Reporte: " & CStr(F.Controls("lstMasiva").List(F.Controls("lstMasiva").ListIndex, 0))
        Case "MANTPARM"
            If gUsuario = "" Then Avisar "MSG-SINLOGIN" Else gTabla = "": Masiva "TABLAS", "Tablas de parámetros (catálogo)"
        Case "SEL_TAB"
            If F.Controls("lstMasiva").ListIndex >= 0 Then gTabla = CStr(F.Controls("lstMasiva").List(F.Controls("lstMasiva").ListIndex, 0)): Masiva gTabla, "Parámetros: " & gTabla
        Case "VOLVER_TAB": Masiva gTabla, "Parámetros: " & gTabla
        Case "NUEVO": EditarFila 0
        Case "EDITAR"
            With F.Controls("lstMasiva")
                If .ListIndex >= 0 Then EditarFila CLng(.List(.ListIndex, .ColumnCount - 1))
            End With
        Case "GUARDAR_PARM": GuardarParm
        Case "RESUMEN": gTabla = "": Masiva "OBJETO", "Consulta: elija el objeto de costo y pulse Ver hoja de costo"
        Case "VER_CALC": VerCalculo gObj
        Case "CONFIRMAR"
            res = ConfirmarPendiente(): Menu
            If res = "OK" Then Avisar "MSG-OK" Else F.Controls("lblMsg").Caption = res
        Case "DESHACER"
            res = DeshacerPendiente(): Menu
            If res = "OK" Then Avisar "MSG-DESHECHO" Else F.Controls("lblMsg").Caption = res
        Case "VER_TRAZA"
            gTabla = "": Masiva "TRAZA", "Fórmulas de " & gObj
            F.Controls("C_BUSCAR").Value = gObj: Llenar gObj
        Case "ALERTAS": ResumenAlertas
        Case "APROBAR_LST"
            If gUsuario = "" Then
                Avisar "MSG-SINLOGIN"
            Else
                gTabla = "": Masiva "PARAM_CAMBIO", "Cambios de parámetros (P = pendiente)"
            End If
        Case "APROBAR", "RECHAZAR"
            With F.Controls("lstMasiva")
                If .ListIndex >= 0 Then
                    F.Controls("lblMsg").Caption = ResolverCambio(.List(.ListIndex, 0), IIf(accion = "APROBAR", "A", "R"))
                End If
            End With
        Case "VER_HOJA"
            If F.Controls("lstMasiva").ListIndex >= 0 Then Resumen CStr(F.Controls("lstMasiva").List(F.Controls("lstMasiva").ListIndex, 0))
        Case "CIERRE"
            If gUsuario = "" Then Avisar "MSG-SINLOGIN" Else gModo = "ACT-BD": Masiva "TRX", "ACT-BD: cadena de cierre (en orden)"
        Case "ESTADIST"
            If gUsuario = "" Then Avisar "MSG-SINLOGIN" Else gModo = "ESTADISTICAS": Masiva "TRX", "ESTADÍSTICAS: fotos, rentabilidad, alertas, proyección"
        Case "REPBATCH"
            If gUsuario = "" Then Avisar "MSG-SINLOGIN" Else gModo = "REPORTES": Masiva "TRX", "REPORTES: kardex valorizado y diario de operaciones"
        Case "EXPORTAR": ExportarHoja
        Case "ANALISIS": AbrirAnalisis
        Case "ESTCONS": Masiva "ESTADISTICAS", "ESTADÍSTICAS: consultar las fotos (centro, objeto, compras, decisiones)"
        Case "AUTOPRUEBA": F.Controls("lblMsg").Caption = "AUTOPRUEBA: " & AutopruebaResumen()
        Case "PENDIENTE": Avisar "MSG-PEND"
        Case "CARGA"
            If gPerfil <> "COSTOS" Then
                Avisar "MSG-SEG"
            Else
                ProcesarCarga
                F.Controls("lblMsg").Caption = CStr(Hoja("MENU").Range("D31").Value)
            End If
    End Select
    Exit Sub
Fallo:
    MsgBox Err.Description, vbExclamation, "Sistema de costos"
End Sub
