VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "clsBoton"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
' Conecta cada botón creado en tiempo de ejecución con su acción (una sola clase para todos).
Option Explicit
Public WithEvents Btn As MSForms.CommandButton
Public Accion As String
Private Sub Btn_Click()
    ventanas.Ejecutar Accion
End Sub
