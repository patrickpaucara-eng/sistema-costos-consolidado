Attribute VB_Name = "operar"
' ============================================================================
' OLA 1b - OPERAR EL MES como usuario: Elegir archivo -> Validar -> Importar -> Cerrar mes -> Ver resultados.
' Mismas reglas y mensajes que kit/usuario/operar_mes.py (referencia probada en Python).
' Plantilla CARGA_MES.xlsx: una hoja por operacion "<TRX> <nombre>"; fila 1 etiquetas, fila 2 codigos, datos desde la 3.
' Columnas fijas: N (orden), DOC (mismo DOC = un documento con varias lineas), USUARIO.
' Una hoja que termina en "(al cerrar)" se registra dentro del cierre, despues de liquidar (T23.3).
' Validar no escribe nada. Importar y cerrar pasan por el puerto CARGA (ProcesarCarga), el camino probado de siempre.
' ============================================================================
Option Explicit
Public gRuta As String
Public nOps As Long
Public opN() As Long, opHoja() As String, opTrx() As String, opUsr() As String, opDoc() As String
Public opRaw() As String, opTrama() As String, opFase() As String, opMsg() As String
Private Const AL_CERRAR As String = "(al cerrar)"
Private Const LIQUIDA As String = "T23.3"
Private Const NUMERICOS As String = "|FECHA|CANT|CU_DOC|MTO_DOC|PVU|AVA|CAN|MONTO|MIN|"
Private Const LINEA_EN_CABECERA As String = "|T14|T15|T17|"
Private Const FIJAS As String = "|N|DOC|USUARIO|"
Private Const SEP_PAR As String = ";", SEP_LIN As String = "~"
Private gHojaAct As String, gFilaAct As Long          ' donde va la lectura, para el mensaje de error en espanol

Public Function ElegirArchivo() As String
    Dim f As Variant
    f = Application.GetOpenFilename("Plantilla del mes (*.xlsx),*.xlsx", , "Elija la plantilla del mes")
    If VarType(f) = vbBoolean Then
        ElegirArchivo = ""
    Else
        gRuta = CStr(f): ElegirArchivo = gRuta
    End If
End Function

Private Function Txt(ByVal v As Variant) As String
    If IsEmpty(v) Or IsNull(v) Then Txt = "": Exit Function
    If VarType(v) = vbDouble Or VarType(v) = vbLong Or VarType(v) = vbInteger Or VarType(v) = vbCurrency Then
        If CDbl(v) = Fix(CDbl(v)) Then
            Txt = Format(CDbl(v), "0")
        Else
            Txt = Replace(CStr(v), ",", ".")
        End If
    Else
        Txt = Trim(CStr(v))
    End If
End Function

Private Sub Crecer()
    nOps = nOps + 1
    ReDim Preserve opN(1 To nOps): ReDim Preserve opHoja(1 To nOps): ReDim Preserve opTrx(1 To nOps)
    ReDim Preserve opUsr(1 To nOps): ReDim Preserve opDoc(1 To nOps): ReDim Preserve opRaw(1 To nOps)
    ReDim Preserve opTrama(1 To nOps): ReDim Preserve opFase(1 To nOps): ReDim Preserve opMsg(1 To nOps)
End Sub

Public Function LeerPlantilla(ByVal ruta As String) As String
    ' Lee la plantilla del usuario y deja las operaciones en memoria (nada se graba). Devuelve "N operaciones leidas".
    Dim wb As Object, ws As Object, r As Long, c As Long, nc As Long, cod() As String, k As Long, i As Long
    Dim lin As String, doc As String, usr As String, n As Long, trx As String, fase As String, v As String, hay As Boolean
    nOps = 0: gHojaAct = "": gFilaAct = 0
    If ruta = "" Then LeerPlantilla = "Elija primero el archivo": Exit Function
    On Error GoTo FalloLeer
    Application.ScreenUpdating = False
    Set wb = Workbooks.Open(ruta, ReadOnly:=True)
    For Each ws In wb.Worksheets
        If UCase(Left(ws.Name, 7)) <> "INSTRUC" Then
            gHojaAct = ws.Name: gFilaAct = 2
            trx = Split(ws.Name, " ")(0)
            If Right(ws.Name, Len(AL_CERRAR)) = AL_CERRAR Then fase = "CIERRE" Else fase = "MES"
            nc = ws.Cells(2, ws.Columns.Count).End(-4159).Column            ' xlToLeft
            ReDim cod(1 To nc)
            For c = 1 To nc: cod(c) = Trim(CStr(ws.Cells(2, c).Value)): Next c
            r = 3
            Do While Application.WorksheetFunction.CountA(ws.Rows(r)) > 0
                gFilaAct = r
                lin = "": doc = "": usr = "": n = 0
                For c = 1 To nc
                    v = Txt(ws.Cells(r, c).Value)
                    If cod(c) = "N" Then
                        If v <> "" Then n = CLng(Val(v))
                    ElseIf cod(c) = "DOC" Then
                        doc = v
                    ElseIf cod(c) = "USUARIO" Then
                        usr = v
                    ElseIf cod(c) <> "" And v <> "" Then
                        lin = lin & IIf(lin = "", "", SEP_PAR) & cod(c) & "=" & v
                    End If
                Next c
                hay = False
                If doc <> "" Then
                    For i = 1 To nOps
                        If opHoja(i) = ws.Name And opDoc(i) = doc Then opRaw(i) = opRaw(i) & SEP_LIN & lin: hay = True: Exit For
                    Next i
                End If
                If Not hay Then
                    Crecer
                    opN(nOps) = n: opHoja(nOps) = ws.Name: opTrx(nOps) = trx: opUsr(nOps) = usr: opDoc(nOps) = doc
                    opRaw(nOps) = lin: opFase(nOps) = fase: opMsg(nOps) = "": opTrama(nOps) = ""
                End If
                r = r + 1
            Loop
        End If
    Next ws
    wb.Close False
    Application.ScreenUpdating = True
    OrdenarPorN
    LeerPlantilla = nOps & " operaciones leídas de " & Dir(ruta)
    Exit Function
FalloLeer:
    LeerPlantilla = MensajeError("leer la plantilla", Err.Description)
    nOps = 0
    On Error Resume Next
    If Not wb Is Nothing Then wb.Close False
    Application.ScreenUpdating = True
End Function

Private Function MensajeError(ByVal accion As String, ByVal detalle As String) As String
    ' Nunca un error de sistema en ingles: siempre "Error en la fila X de la hoja H: motivo"
    If gHojaAct <> "" And gFilaAct > 0 Then
        MensajeError = "Error en la fila " & gFilaAct & " de la hoja «" & gHojaAct & "» al " & accion & ": " & Traducir(detalle)
    Else
        MensajeError = "Error al " & accion & ": " & Traducir(detalle)
    End If
End Function

Private Function Traducir(ByVal d As String) As String
    ' Mensajes frecuentes de Excel en ingles -> espanol; si no se reconoce, se da uno general (sin texto tecnico)
    Select Case True
        Case InStr(1, d, "Type mismatch", vbTextCompare) > 0: Traducir = "hay un dato de tipo incorrecto (texto donde va un número o al revés)"
        Case InStr(1, d, "Subscript out of range", vbTextCompare) > 0: Traducir = "falta una hoja o una columna esperada en la plantilla"
        Case InStr(1, d, "Overflow", vbTextCompare) > 0: Traducir = "un número es demasiado grande"
        Case InStr(1, d, "could not be found", vbTextCompare) > 0, InStr(1, d, "no se encuentra", vbTextCompare) > 0: Traducir = "no se encontró el archivo"
        Case InStr(1, d, "Permission", vbTextCompare) > 0, InStr(1, d, "locked", vbTextCompare) > 0: Traducir = "el archivo está abierto o bloqueado; ciérrelo y vuelva a intentar"
        Case Else: Traducir = "dato no válido (" & d & "). Revise la fila indicada y vuelva a validar"
    End Select
End Function

Private Sub OrdenarPorN()
    Dim i As Long, j As Long
    For i = 1 To nOps - 1
        For j = i + 1 To nOps
            If opN(j) < opN(i) Then Cambiar i, j
        Next j
    Next i
End Sub
Private Sub Cambiar(ByVal i As Long, ByVal j As Long)
    Dim tL As Long, t As String
    tL = opN(i): opN(i) = opN(j): opN(j) = tL
    t = opHoja(i): opHoja(i) = opHoja(j): opHoja(j) = t
    t = opTrx(i): opTrx(i) = opTrx(j): opTrx(j) = t
    t = opUsr(i): opUsr(i) = opUsr(j): opUsr(j) = t
    t = opDoc(i): opDoc(i) = opDoc(j): opDoc(j) = t
    t = opRaw(i): opRaw(i) = opRaw(j): opRaw(j) = t
    t = opFase(i): opFase(i) = opFase(j): opFase(j) = t
End Sub

Private Function CampoTRX(ByVal trx As String, ByVal var As String, ByVal colRes As Long) As String
    ' TRX_CAMPO: columna 3 = variable, 5 = nivel (C/L), 6 = lista "TABLA.COLUMNA". Vacio si el campo no es de la operacion.
    Dim f As Variant, i As Long
    f = Filas("TRX_CAMPO", "TCA_TRX", trx, "")
    For i = 1 To f(0)
        If CStr(Hoja("TRX_CAMPO").Cells(f(i), 3).Value) = var Then CampoTRX = CStr(Hoja("TRX_CAMPO").Cells(f(i), colRes).Value): Exit Function
    Next i
    CampoTRX = "#NO"
End Function

Private Function ValorDe(ByVal linea As String, ByVal var As String) As String
    Dim p As Variant
    For Each p In Split(linea, SEP_PAR)
        If Left(p, Len(var) + 1) = var & "=" Then ValorDe = Mid(p, Len(var) + 2): Exit Function
    Next p
End Function

Private Function ArmarTrama(ByVal i As Long) As String
    ' Cabecera = campos C de la primera linea; cada linea aporta sus campos L (mismo orden de columnas que la plantilla).
    Dim lineas() As String, p As Variant, k As Long, cab As String, l As String, todas As String, nl As Long
    lineas = Split(opRaw(i), SEP_LIN)
    For Each p In Split(lineas(0), SEP_PAR)
        If p <> "" Then
            If CampoTRX(opTrx(i), Split(p, "=")(0), 5) = "C" Then cab = cab & IIf(cab = "", "", ";") & p
        End If
    Next p
    For k = 0 To UBound(lineas)
        l = ""
        For Each p In Split(lineas(k), SEP_PAR)
            If p <> "" Then
                If CampoTRX(opTrx(i), Split(p, "=")(0), 5) = "L" Then l = l & IIf(l = "", "", ";") & p
            End If
        Next p
        If l <> "" Then todas = todas & "|" & l: nl = nl + 1
    Next k
    If nl = 0 Then
        ArmarTrama = cab
    ElseIf nl = 1 And InStr(LINEA_EN_CABECERA, "|" & opTrx(i) & "|") > 0 Then
        ArmarTrama = cab & ";" & Mid(todas, 2)
    Else
        ArmarTrama = cab & todas
    End If
End Function

Private Function EsNumero(ByVal s As String) As Boolean
    If s = "" Or s = "-" Or s = "." Then Exit Function
    If s Like "*[!0-9.-]*" Then Exit Function
    If Len(s) - Len(Replace(s, ".", "")) > 1 Then Exit Function
    If InStr(2, s, "-") > 0 Then Exit Function
    EsNumero = True
End Function

Private Function UsuarioPuedeOp(ByVal usr As String, ByVal trx As String) As Boolean
    Dim uSave As String, pSave As String, fu As Variant
    uSave = gUsuario: pSave = gPerfil
    gUsuario = usr
    fu = Filas("USUARIO", "USU_COD", usr, "")
    If fu(0) > 0 Then gPerfil = CStr(Hoja("USUARIO").Cells(fu(1), 3).Value) Else gPerfil = ""
    UsuarioPuedeOp = PuedeOperar(trx)
    gUsuario = uSave: gPerfil = pSave
End Function

Private Function ValidarUna(ByVal i As Long) As String
    Dim fu As Variant, empUsr As String, lineas() As String, k As Long, p As Variant, c As String, v As String, niv As String, lst As String
    Dim t As String, col As String, per As String, emp As String, fp As Variant, j As Long, hallado As Boolean, est As String, r As Long
    opTrama(i) = ArmarTrama(i)
    If Filas("TRX", "TRX_COD", opTrx(i), "")(0) = 0 Then ValidarUna = "la operación " & opTrx(i) & " no existe": Exit Function
    fu = Filas("USUARIO", "USU_COD", opUsr(i), "")
    If fu(0) = 0 Then ValidarUna = "el usuario " & opUsr(i) & " no existe": Exit Function
    If Not UsuarioPuedeOp(opUsr(i), opTrx(i)) Then ValidarUna = "el usuario " & opUsr(i) & " no está autorizado para " & opTrx(i): Exit Function
    empUsr = CStr(Hoja("USUARIO").Cells(fu(1), ColIdx("USUARIO", "USU_EMP")).Value)
    lineas = Split(opRaw(i), SEP_LIN)
    For k = 0 To UBound(lineas)
        For Each p In Split(lineas(k), SEP_PAR)
            If p <> "" Then
                c = Split(p, "=")(0): v = Mid(p, Len(c) + 2)
                niv = CampoTRX(opTrx(i), c, 5)
                If niv = "#NO" Then ValidarUna = "la columna " & c & " no es un campo de " & opTrx(i): Exit Function
                If InStr(NUMERICOS, "|" & c & "|") > 0 And Not EsNumero(v) Then ValidarUna = c & " debe ser un número (dice «" & v & "»)": Exit Function
                If c = "EMP" And v <> empUsr Then ValidarUna = "la empresa " & v & " no es la del usuario (" & empUsr & ")": Exit Function
                lst = CampoTRX(opTrx(i), c, 6)
                If InStr(lst, ".") > 0 Then
                    t = Left(lst, InStr(lst, ".") - 1): col = Mid(lst, InStr(lst, ".") + 1)
                    If Filas(t, col, v, "")(0) = 0 Then ValidarUna = c & " = «" & v & "» no existe en " & t: Exit Function
                End If
            End If
        Next p
    Next k
    per = ValorDe(lineas(0), "PER"): emp = ValorDe(lineas(0), "EMP")
    If emp = "" Then emp = empUsr
    If per <> "" Then
        fp = Filas("PERIODO", "PER_COD", per, "")
        For j = 1 To fp(0)
            If CStr(Hoja("PERIODO").Cells(fp(j), ColIdx("PERIODO", "PER_EMP")).Value) = emp Then hallado = True: est = CStr(Hoja("PERIODO").Cells(fp(j), ColIdx("PERIODO", "PER_EST")).Value): Exit For
        Next j
        If Not hallado Then ValidarUna = "el periodo " & per & " de la empresa " & emp & " no existe": Exit Function
        If est <> "A" Then ValidarUna = "el periodo " & per & " de la empresa " & emp & " no está abierto": Exit Function
    End If
    For r = 2 To UltFila("CARGA")
        If CStr(Hoja("CARGA").Cells(r, 2).Value) = opTrx(i) And CStr(Hoja("CARGA").Cells(r, 3).Value) = opUsr(i) _
           And CStr(Hoja("CARGA").Cells(r, 4).Value) = opTrama(i) And CStr(Hoja("CARGA").Cells(r, 5).Value) = "OK" Then
            ValidarUna = "ya importada antes (no se duplica)": Exit Function
        End If
    Next r
    ValidarUna = "OK"
End Function

Public Function ValidarImportacion() As String
    ' Devuelve "N de M filas OK"; el detalle queda en opMsg(). No escribe nada en la base.
    Dim i As Long, ok As Long
    If nOps = 0 Then ValidarImportacion = "No hay operaciones leídas: elija el archivo": Exit Function
    On Error GoTo FalloVal
    For i = 1 To nOps
        gHojaAct = opHoja(i): gFilaAct = 0
        opMsg(i) = ValidarUna(i)
        If opMsg(i) = "OK" Then ok = ok + 1
    Next i
    ValidarImportacion = ok & " de " & nOps & " filas OK" & IIf(ok < nOps, " - corrija las observadas y vuelva a validar (no se importa nada)", " - lista para importar")
    Exit Function
FalloVal:
    opMsg(i) = "Error: " & Traducir(Err.Description)
    ValidarImportacion = "Error en la operación Nº " & opN(i) & " de la hoja «" & opHoja(i) & "» al validar: " & Traducir(Err.Description) & " (no se importa nada)"
End Function

Private Function TodoValido() As Boolean
    Dim i As Long
    If nOps = 0 Then Exit Function
    For i = 1 To nOps
        If opMsg(i) <> "OK" Then Exit Function
    Next i
    TodoValido = True
End Function

Private Sub AgregarACarga(ByVal trx As String, ByVal usr As String, ByVal trama As String)
    Dim n As Long
    n = UltFila("CARGA") + 1
    With Hoja("CARGA")
        .Cells(n, 1).Value = n - 1: .Cells(n, 2).Value = trx: .Cells(n, 3).Value = usr: .Cells(n, 4).Value = trama
    End With
End Sub

Private Function ResumenCarga(ByVal desde As Long) As String
    Dim r As Long, ok As Long, er As Long, primero As String
    For r = desde To UltFila("CARGA")
        If CStr(Hoja("CARGA").Cells(r, 5).Value) = "OK" Then
            ok = ok + 1
        Else
            er = er + 1
            If primero = "" Then primero = Hoja("CARGA").Cells(r, 2).Value & ": " & Hoja("CARGA").Cells(r, 6).Value
        End If
    Next r
    ResumenCarga = ok & " registradas" & IIf(er > 0, ", " & er & " con error (" & primero & ")", "")
End Function

Public Function ImportarValidadas() As String
    ' Todo o nada: si una fila no paso la validacion, no se importa ninguna. Las hojas "(al cerrar)" esperan al cierre.
    Dim i As Long, desde As Long
    If Not TodoValido() Then ImportarValidadas = "ERROR: hay filas con observaciones; corríjalas y vuelva a validar": Exit Function
    On Error GoTo FalloImp
    desde = UltFila("CARGA") + 1
    For i = 1 To nOps
        If opFase(i) = "MES" Then AgregarACarga opTrx(i), opUsr(i), opTrama(i)
    Next i
    ProcesarCarga
    For i = 1 To nOps
        If opFase(i) = "MES" Then opMsg(i) = "IMPORTADA" Else opMsg(i) = "ESPERA AL CIERRE"
    Next i
    ImportarValidadas = "Importación: " & ResumenCarga(desde)
    Exit Function
FalloImp:
    ImportarValidadas = "Error al importar: " & Traducir(Err.Description) & ". Revise la hoja CARGA desde la fila " & desde
End Function

Public Function CerrarMes(ByVal per As String, ByVal emp As String) As String
    ' Cierre oficial en el orden de CIERRE_PASO (OFICIAL y CIERRE); las operaciones "(al cerrar)" entran despues de liquidar.
    Dim r As Long, n As Long, pasos() As String, ords() As Long, i As Long, j As Long, t As String, tl As Long, desde As Long, tipo As String
    If gUsuario = "" Then CerrarMes = "Ingrese primero (SEGURIDAD)": Exit Function
    If per = "" Or Not (per Like "####-##") Then CerrarMes = "Escriba el periodo como AAAA-MM (por ejemplo 2026-09)": Exit Function
    On Error GoTo FalloCierre
    For r = 2 To UltFila("CIERRE_PASO")
        tipo = CStr(Hoja("CIERRE_PASO").Cells(r, 5).Value)
        If tipo = "OFICIAL" Or tipo = "CIERRE" Then
            n = n + 1: ReDim Preserve pasos(1 To n): ReDim Preserve ords(1 To n)
            pasos(n) = CStr(Hoja("CIERRE_PASO").Cells(r, 1).Value): ords(n) = CLng(Hoja("CIERRE_PASO").Cells(r, 2).Value)
        End If
    Next r
    For i = 1 To n - 1
        For j = i + 1 To n
            If ords(j) < ords(i) Then tl = ords(i): ords(i) = ords(j): ords(j) = tl: t = pasos(i): pasos(i) = pasos(j): pasos(j) = t
        Next j
    Next i
    desde = UltFila("CARGA") + 1
    For i = 1 To n
        AgregarACarga pasos(i), gUsuario, "PER=" & per & ";EMP=" & emp
        If pasos(i) = LIQUIDA Then
            For j = 1 To nOps
                If opFase(j) = "CIERRE" And opMsg(j) <> "IMPORTADA" Then AgregarACarga opTrx(j), opUsr(j), opTrama(j): opMsg(j) = "IMPORTADA (al cerrar)"
            Next j
        End If
    Next i
    ProcesarCarga
    CerrarMes = "Cierre de " & per & ": " & ResumenCarga(desde)
    Exit Function
FalloCierre:
    CerrarMes = "Error al cerrar " & per & ": " & Traducir(Err.Description) & ". Revise la hoja CARGA"
End Function
