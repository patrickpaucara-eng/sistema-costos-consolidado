Attribute VB_Name = "paridad"
' ============================================================================
' OT-105 · PARIDAD AUTOMATICA EXCEL <-> ESPEJO
' ExportarParidad recorre las tablas listadas en la hoja PARIDAD (columna A,
' desde la fila 2) y escribe paridad_excel.csv junto al libro con:
'   tabla,fila,columna,valor
' Los numeros salen con punto decimal sin depender de la configuracion
' regional (Str, no Format ni CStr); fechas como aaaa-mm-dd[ hh:mm:ss];
' logicos como TRUE/FALSE; texto entre comillas.
' Se compara con:  python3 kit/instalador/comparar_paridad.py paridad_excel.csv Sistema_Costos.xlsx --carga
' Usa Hoja, UltFila, NCols, EsNum y Num de motor.bas (no los copia).
' ============================================================================
Option Explicit
Private Const PAR_HOJA As String = "PARIDAD"
Private Const PAR_ARCHIVO As String = "paridad_excel.csv"

Public Sub ExportarParidad()
    Dim wsPar As Object, nPar As Long, k As Long, nomTab As String
    Dim wsTab As Object, nFil As Long, nCol As Long, r As Long, c As Long
    Dim ruta As String, f As Integer, nLin As Long
    On Error GoTo Fallo
    Set wsPar = Hoja(PAR_HOJA)
    nPar = UltFila(PAR_HOJA)
    ruta = RutaParidad()
    f = FreeFile
    Open ruta For Output As #f
    Print #f, "tabla,fila,columna,valor"
    For k = 2 To nPar
        nomTab = Trim(CStr(wsPar.Cells(k, 1).Value))
        If nomTab <> "" Then
            Set wsTab = Hoja(nomTab)
            nFil = UltFila(nomTab): nCol = NCols(nomTab)
            For r = 2 To nFil
                For c = 1 To nCol
                    Print #f, CampoCsv(nomTab) & "," & r & "," & CampoCsv(CStr(wsTab.Cells(1, c).Value)) & "," & ValorCsv(wsTab.Cells(r, c).Value)
                    nLin = nLin + 1
                Next c
            Next r
        End If
    Next k
    Close #f
    If Not gSilencio Then MsgBox "Paridad exportada: " & nLin & " celda(s) en " & ruta, vbInformation, "ExportarParidad"
    Exit Sub
Fallo:
    If f <> 0 Then Close #f
    MsgBox "ExportarParidad no pudo terminar (tabla '" & nomTab & "'): " & Err.Description & _
           vbCrLf & "Revise que la hoja PARIDAD liste en la columna A nombres de hojas existentes.", vbExclamation, "ExportarParidad"
End Sub

Private Function RutaParidad() As String
    Dim carp As String, sep As String
    carp = ThisWorkbook.Path
    If InStr(carp, "/") > 0 And InStr(carp, "\") = 0 Then sep = "/" Else sep = "\"
    If Right(carp, 1) = sep Then RutaParidad = carp & PAR_ARCHIVO Else RutaParidad = carp & sep & PAR_ARCHIVO
End Function

Private Function CampoCsv(ByVal s As String) As String
    CampoCsv = """" & Replace(s, """", """""") & """"
End Function

Private Function NumPunto(ByVal x As Double) As String
    ' Str siempre usa punto decimal (no depende de la configuracion regional); deja un espacio delante de los positivos
    NumPunto = Trim(Str(x))
End Function

Private Function Dos(ByVal n As Long) As String
    Dos = Right("0" & Trim(Str(n)), 2)
End Function

Private Function ValorCsv(ByVal v As Variant) As String
    Dim fecha As String
    If IsEmpty(v) Or IsNull(v) Then
        ValorCsv = ""
    ElseIf IsError(v) Then
        ValorCsv = CampoCsv("#ERROR")
    ElseIf VarType(v) = vbBoolean Then
        If v Then ValorCsv = "TRUE" Else ValorCsv = "FALSE"
    ElseIf VarType(v) = vbDate Then
        fecha = Trim(Str(Year(v))) & "-" & Dos(Month(v)) & "-" & Dos(Day(v))
        If Hour(v) <> 0 Or Minute(v) <> 0 Or Second(v) <> 0 Then fecha = fecha & " " & Dos(Hour(v)) & ":" & Dos(Minute(v)) & ":" & Dos(Second(v))
        ValorCsv = fecha
    ElseIf EsNum(v) Then
        ValorCsv = NumPunto(Num(v))
    Else
        ValorCsv = CampoCsv(CStr(v))
    End If
End Function
