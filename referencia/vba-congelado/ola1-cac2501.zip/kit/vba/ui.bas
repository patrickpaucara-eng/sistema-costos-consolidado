Attribute VB_Name = "ui"
' ============================================================================
' INTERFAZ: menú del diseño arquitectónico, ingreso con perfil, captura y autoprueba
' ============================================================================
Option Explicit

Private Sub Aviso(ByVal t As String)
    If Not gSilencio Then MsgBox t, vbInformation, "Sistema de costos"
End Sub
Public Function Login(ByVal u As String, ByVal clave As String) As Boolean
    Dim f As Variant
    f = Filas("USUARIO", "USU_COD", u, "")
    If f(0) = 0 Then Exit Function
    If CStr(Hoja("USUARIO").Cells(f(1), ColIdx("USUARIO", "USU_CLAVE")).Value) <> ClaveCifrada(u, clave) Then Exit Function   ' E-098: solo se guarda la huella
    gUsuario = u: gPerfil = CStr(Hoja("USUARIO").Cells(f(1), ColIdx("USUARIO", "USU_PERFIL")).Value)
    Hoja("MENU").Range("C5").Value = gUsuario: Hoja("MENU").Range("C6").Value = gPerfil
    Login = True
End Function
Private Sub LimpiarParque()
    ' Estado inicial de la prueba, leído de TABLAS_LOGICAS: el PARQUE se vacía y el PARQUE-SEMILLA se repone desde SEM_<tabla>.
    Dim r As Long, nom As String, tipo As String, ws As Object, ur As Long, src As Object, n As Long
    For r = 2 To UltFila("TABLAS_LOGICAS")
        nom = CStr(Hoja("TABLAS_LOGICAS").Cells(r, 1).Value): tipo = CStr(Hoja("TABLAS_LOGICAS").Cells(r, 2).Value)
        If tipo = "PARQUE" Or tipo = "PARQUE-SEMILLA" Then
            Set ws = Hoja(nom): ur = UltFila(nom)
            If ur >= 2 Then ws.Range(ws.Cells(2, 1), ws.Cells(ur, NCols(nom))).ClearContents
            If tipo = "PARQUE-SEMILLA" Then
                Set src = Hoja("SEM_" & nom): n = UltFila("SEM_" & nom)
                If n >= 2 Then ws.Range(ws.Cells(2, 1), ws.Cells(n, NCols(nom))).Value = src.Range(src.Cells(2, 1), src.Cells(n, NCols(nom))).Value
            End If
        End If
    Next r
    Set ws = Hoja("RESULTADO"): ur = UltFila("RESULTADO")
    If ur >= 2 Then ws.Range(ws.Cells(2, 1), ws.Cells(ur, 6)).ClearContents
End Sub
Private Sub Escribir(ByVal tipo As String, ByVal ref As Variant, ByVal det As String, ByVal esp As Variant, ByVal obt As Variant, ByVal est As String)
    Dim r As Long, ws As Object: Set ws = Hoja("RESULTADO"): r = UltFila("RESULTADO") + 1
    ws.Cells(r, 1).Value = tipo: ws.Cells(r, 2).Value = ref: ws.Cells(r, 3).Value = det
    ws.Cells(r, 4).Value = esp: ws.Cells(r, 5).Value = obt: ws.Cells(r, 6).Value = est
End Sub
Public Function AutopruebaResumen() As String
    ' Cada escenario se ejecuta y, en ese momento, se comprueban sus valores esperados (ESP_ESC = escenario).
    Dim ws As Object, r As Long, res As String, esp As String, ok As Boolean, nP As Long, nF As Long, k As Long
    Dim uSave As String, pSave As String, fu As Variant, partes() As String, lin() As String
    uSave = gUsuario: pSave = gPerfil
    On Error Resume Next
    Application.ScreenUpdating = False: Application.Calculation = -4135   ' cálculo manual mientras corre (más rápido)
    On Error GoTo 0
    LimpiarParque
    Set ws = Hoja("ESCENARIO")
    For r = 2 To UltFila("ESCENARIO")
        gUsuario = CStr(ws.Cells(r, 4).Value)
        fu = Filas("USUARIO", "USU_COD", gUsuario, "")
        gPerfil = CStr(Hoja("USUARIO").Cells(fu(1), 3).Value)
        TReset
        If CStr(ws.Cells(r, 5).Value) <> "" Then
            partes = Split(CStr(ws.Cells(r, 5).Value), "|"): CargarTrama partes(0)
        Else
            partes = Split("x", "|")
        End If
        If CStr(ws.Cells(r, 3).Value) = "@CARGA" Then
            res = ProcesarCarga()
        ElseIf CStr(ws.Cells(r, 3).Value) = "@PROPONER" Or CStr(ws.Cells(r, 3).Value) = "PROPONER" Then
            res = ProponerCambio(CStr(TGet("TABLA")), TGet("CLAVE"), CStr(TGet("COL")), TGet("VALOR"), TOpc("MOTIVO"), TOpc("PAQ") & TOpc("PCA_PAQ"), TOpc("PROP") & TOpc("PCA_PROP"))
        ElseIf CStr(ws.Cells(r, 3).Value) = "@INVPROC" Then          ' V4.1 I-1 (OT-095): K9 a INV_PROCESO
            res = InvProc(TOpc("PER"), TOpc("OBJ"), TOpc("ELE"), TGet("VAL"), TOpc("EMP"))
        ElseIf CStr(ws.Cells(r, 3).Value) = "@SEGUIM" Then           ' I-2 (OT-098): seguimiento de decisiones a EST_DECISION
            res = Seguim(TGet("REF"), TOpc("OBJ"), TOpc("PER"), TGet("PRED"), TGet("REAL"), TGet("ERR"), TOpc("ESTADO"), TOpc("REGLA"))
        ElseIf CStr(ws.Cells(r, 3).Value) = "@NIVEL" Then            ' I-2 (OT-098 V7): degradación AUT-01 en PROPUESTA
            res = BajarNivel(TOpc("PRO"), TGet("NIVEL"))
        ElseIf CStr(ws.Cells(r, 3).Value) = "@RESOLVER" Or CStr(ws.Cells(r, 3).Value) = "APRUEBA-PARM" Then
            res = ResolverCambio(NumPropuesta(TOpc("NUM"), TOpc("PCA_PAQ")), IIf(TOpc("DEC") = "", "A", TOpc("DEC")), TOpc("DESDE"), TOpc("MOTIVO"))
        ElseIf CStr(ws.Cells(r, 3).Value) = "@CONFIRMAR" Then
            res = ConfirmarPendiente()
        ElseIf CStr(ws.Cells(r, 3).Value) = "@DESHACER" Then
            res = DeshacerPendiente()
        ElseIf CStr(ws.Cells(r, 3).Value) = "@REINICIAR" Then
            Reiniciar
            res = "OK"
        ElseIf UBound(partes) >= 1 Then
            ReDim lin(0 To UBound(partes) - 1)
            For k = 1 To UBound(partes): lin(k - 1) = partes(k): Next k
            res = EjecutarTRX(CStr(ws.Cells(r, 3).Value), lin)
        Else
            res = EjecutarTRX(CStr(ws.Cells(r, 3).Value))
        End If
        esp = CStr(ws.Cells(r, 6).Value)
        If esp = "OK" Then
            ok = (res = "OK")
        Else
            ok = (Left(res, 5) = "ERROR") And (InStr(res, Trim(Mid(esp, InStr(esp, ":") + 1))) > 0)
        End If
        If ok Then nP = nP + 1 Else nF = nF + 1
        Escribir "ESCENARIO", ws.Cells(r, 1).Value, ws.Cells(r, 3).Value & " " & ws.Cells(r, 7).Value, esp, res, IIf(ok, "PASA", "FALLA")
        Chequear ws.Cells(r, 1).Value, nP, nF
    Next r
    gUsuario = uSave: gPerfil = pSave
    On Error Resume Next
    Application.Calculation = -4105: Application.ScreenUpdating = True
    On Error GoTo 0
    AutopruebaResumen = (nP + nF) & " pruebas · " & nP & " PASA · " & nF & " FALLA"
    Hoja("MENU").Range("D30").Value = AutopruebaResumen & IIf(nF = 0, "  -> TODO PASA", "  -> REVISAR hoja RESULTADO")
End Function
Private Sub Chequear(ByVal esc As Variant, ByRef nP As Long, ByRef nF As Long)
    Dim e As Object, r As Long, filtro() As String, i As Long, tabla As String, col As String, got As Variant, k As Long
    Dim cumple As Boolean, p As Long, hallado As Boolean, ok As Boolean, esperado As Variant
    Set e = Hoja("ESPERADO")
    For r = 2 To UltFila("ESPERADO")
        If Norm(e.Cells(r, 1).Value) = Norm(esc) Then
            tabla = CStr(e.Cells(r, 2).Value): col = CStr(e.Cells(r, 4).Value): esperado = e.Cells(r, 5).Value
            filtro = Split(CStr(e.Cells(r, 3).Value), ";")
            hallado = False: got = ""
            For k = 2 To UltFila(tabla)
                cumple = True
                For i = LBound(filtro) To UBound(filtro)
                    p = InStr(filtro(i), "=")
                    If Norm(Hoja(tabla).Cells(k, ColIdx(tabla, Left(filtro(i), p - 1))).Value) <> Norm(ParseValor(Mid(filtro(i), p + 1))) Then cumple = False
                Next i
                If cumple Then
                    got = Hoja(tabla).Cells(k, ColIdx(tabla, col)).Value: hallado = True
                    Exit For
                End If
            Next k
            ok = hallado
            If ok Then
                If EsNum(esperado) Then
                    ok = (CStr(got) <> "") And (Abs(Num(got) - Num(esperado)) <= 0.005)
                Else
                    ok = (Norm(got) = Norm(esperado))
                End If
            End If
            If ok Then nP = nP + 1 Else nF = nF + 1
            Escribir "VALOR", esc, tabla & "." & col & " [" & e.Cells(r, 3).Value & "] " & e.Cells(r, 6).Value, esperado, got, IIf(ok, "PASA", "FALLA")
        End If
    Next r
End Sub
Public Function EmpresaUsuario() As String
    Dim fu As Variant
    On Error Resume Next
    fu = Filas("USUARIO", "USU_COD", gUsuario, "")
    If fu(0) > 0 Then EmpresaUsuario = CStr(Hoja("USUARIO").Cells(fu(1), ColIdx("USUARIO", "USU_EMP")).Value)
End Function
Public Function DobleControl() As Boolean
    Dim f As Variant
    On Error Resume Next
    f = Filas("PARAMETRO", "PAR_COD", "DOBLE_CONTROL", "")
    If f(0) > 0 Then DobleControl = (UCase(CStr(Hoja("PARAMETRO").Cells(f(1), 2).Value)) = "S")
End Function
Private Sub ImportarBandeja()
    ' La pantalla de análisis deja sus decisiones en bandeja_carga.csv (separado por tabulador) junto al libro.
    ' Cada línea pasa a la hoja CARGA y el archivo se renombra como procesado: así nada se carga dos veces.
    ' SEGURIDAD (E-097): el archivo no está autenticado. Responde quien procesa (usuario con sesión), no el usuario escrito
    ' en el archivo: ese queda solo como solicitante (CAR_SOLICITA). Sin sesión iniciada, la bandeja no se importa.
    Dim ruta As String, nf As Integer, txt As String, c() As String, ws As Object, r As Long, n As Long, primera As Boolean, cSol As Long
    On Error GoTo FinB
    ruta = ThisWorkbook.Path & Application.PathSeparator & "bandeja_carga.csv"
    If Dir(ruta) = "" Then Exit Sub
    If gUsuario = "" Then Exit Sub
    cSol = ColIdx("CARGA", "CAR_SOLICITA")
    Set ws = Hoja("CARGA"): n = 0
    For r = 2 To UltFila("CARGA")
        If Num(ws.Cells(r, 1).Value) > n Then n = Num(ws.Cells(r, 1).Value)
    Next r
    nf = FreeFile: primera = True
    Open ruta For Input As #nf
    Do While Not EOF(nf)
        Line Input #nf, txt
        If primera Then
            primera = False
        ElseIf Trim(txt) <> "" Then
            c = Split(txt, vbTab)
            If UBound(c) >= 2 Then
                n = n + 1: r = UltFila("CARGA") + 1
                ws.Cells(r, 1).Value = n: ws.Cells(r, 2).Value = c(0): ws.Cells(r, 3).Value = gUsuario: ws.Cells(r, 4).Value = c(2)
                If cSol > 0 Then ws.Cells(r, cSol).Value = c(1)
            End If
        End If
    Loop
    Close #nf
    Name ruta As ThisWorkbook.Path & Application.PathSeparator & "bandeja_procesada_" & Format(Now, "yyyymmdd_hhnnss") & ".csv"
    Exit Sub
FinB:
    On Error Resume Next
    Close #nf
End Sub
Public Function ProcesarCarga() As String
    ' Puerto de carga: cada fila de CARGA (sensor, balanza, QR) se ejecuta como transacción con su usuario de captura.
    Dim ws As Object, r As Long, partes() As String, lin() As String, k As Long, res As String, fu As Variant, uSave As String, pSave As String, nOk As Long, nErr As Long
    uSave = gUsuario: pSave = gPerfil
    ImportarBandeja                           ' decisiones que dejó la pantalla de análisis (puerto por archivo)
    Set ws = Hoja("CARGA")
    For r = 2 To UltFila("CARGA")
        If CStr(ws.Cells(r, 5).Value) = "OK" Then GoTo Siguiente   ' ya registrada: no se duplica; las con ERROR se reintentan
        gUsuario = CStr(ws.Cells(r, 3).Value)
        fu = Filas("USUARIO", "USU_COD", gUsuario, "")
        If fu(0) > 0 Then gPerfil = CStr(Hoja("USUARIO").Cells(fu(1), 3).Value) Else gPerfil = ""
        partes = Split(CStr(ws.Cells(r, 4).Value), "|")
        TReset
        CargarTrama partes(0)
        If CStr(ws.Cells(r, 2).Value) = "@PROPONER" Or CStr(ws.Cells(r, 2).Value) = "PROPONER" Then          ' V4.1 §9.7 #6: canal de la capa analítica
            res = ProponerCambio(CStr(TGet("TABLA")), TGet("CLAVE"), CStr(TGet("COL")), TGet("VALOR"), TOpc("MOTIVO"), TOpc("PAQ") & TOpc("PCA_PAQ"), TOpc("PROP") & TOpc("PCA_PROP"))
        ElseIf CStr(ws.Cells(r, 2).Value) = "@INVPROC" Then          ' V4.1 I-1 (OT-095): K9 a INV_PROCESO
            res = InvProc(TOpc("PER"), TOpc("OBJ"), TOpc("ELE"), TGet("VAL"), TOpc("EMP"))
        ElseIf CStr(ws.Cells(r, 2).Value) = "@SEGUIM" Then           ' I-2 (OT-098): seguimiento de decisiones a EST_DECISION
            res = Seguim(TGet("REF"), TOpc("OBJ"), TOpc("PER"), TGet("PRED"), TGet("REAL"), TGet("ERR"), TOpc("ESTADO"), TOpc("REGLA"))
        ElseIf CStr(ws.Cells(r, 2).Value) = "@NIVEL" Then            ' I-2 (OT-098 V7): degradación AUT-01 en PROPUESTA
            res = BajarNivel(TOpc("PRO"), TGet("NIVEL"))
        ElseIf CStr(ws.Cells(r, 2).Value) = "@RESOLVER" Or CStr(ws.Cells(r, 2).Value) = "APRUEBA-PARM" Then
            res = ResolverCambio(NumPropuesta(TOpc("NUM"), TOpc("PCA_PAQ")), IIf(TOpc("DEC") = "", "A", TOpc("DEC")), TOpc("DESDE"), TOpc("MOTIVO"))
        ElseIf UBound(partes) >= 1 Then
            ReDim lin(0 To UBound(partes) - 1)
            For k = 1 To UBound(partes): lin(k - 1) = partes(k): Next k
            res = EjecutarTRX(CStr(ws.Cells(r, 2).Value), lin)
        Else
            res = EjecutarTRX(CStr(ws.Cells(r, 2).Value))
        End If
        ws.Cells(r, 5).Value = IIf(res = "OK", "OK", "ERROR"): ws.Cells(r, 6).Value = res
        If res = "OK" Then nOk = nOk + 1 Else nErr = nErr + 1
Siguiente:
    Next r
    gUsuario = uSave: gPerfil = pSave
    Hoja("MENU").Range("D31").Value = "Última carga: " & nOk & " filas OK, " & nErr & " con error (ver hoja CARGA)"
    ProcesarCarga = "OK"
End Function
Public Sub Autoprueba()
    Dim s As String
    s = AutopruebaResumen()
    Aviso "AUTOPRUEBA: " & s & vbCrLf & "Detalle en la hoja RESULTADO."
    Hoja("RESULTADO").Activate
End Sub

' ---------------- crea los botones del árbol (DBD Fig. 1.3) en la hoja MENU
Private Sub Boton(ByVal ws As Object, ByVal fila As Long, ByVal col As Long, ByVal texto As String, ByVal macro As String)
    Dim b As Object, x As Double, y As Double
    x = ws.Cells(fila, col).Left: y = ws.Cells(fila, col).Top
    Set b = ws.Buttons.Add(x, y, 120, 26)
    b.Caption = texto: b.OnAction = macro
End Sub
Public Sub Auto_Open()
    On Error Resume Next
    ProtegerHojas                             ' Ola 1b: se vuelve a aplicar al abrir (UserInterfaceOnly no se guarda con el libro)
    ventanas.AbrirApp
End Sub
Public Sub CrearVentana()
    If VentanaCreada() Then Aviso "Ventana creada. Ejecute AbrirApp o guarde y vuelva a abrir el libro."
End Sub
Private Function VentanaCreada() As Boolean
    Dim vbp As Object, vbc As Object, existe As Boolean, i As Long
    On Error GoTo SinConfianza
    Set vbp = ThisWorkbook.VBProject
    On Error Resume Next
    vbp.References.AddFromGuid "{0D452EE1-E08F-101A-852E-02608C4D0BB4}", 2, 0
    On Error GoTo SinConfianza
    For i = 1 To vbp.VBComponents.Count
        If vbp.VBComponents(i).Name = "frmApp" Then existe = True
    Next i
    If Not existe Then
        Set vbc = vbp.VBComponents.Add(3)
        vbc.Name = "frmApp"
        vbc.CodeModule.AddFromString "Private Sub UserForm_Initialize()" & vbCrLf & "    ventanas.Iniciar Me" & vbCrLf & "End Sub"
    End If
    VentanaCreada = True
    Exit Function
SinConfianza:
    If Not gSilencio Then MsgBox Mensaje("MSG-CONFIANZA"), vbExclamation, "Sistema de costos"
    VentanaCreada = False
End Function
Private Function InstalarNucleo() As Boolean
    ' La aplicación se usa solo desde la ventana estándar (decisión del usuario, E-074). En la hoja quedan dos botones.
    Dim ws As Object: Set ws = Hoja("MENU")
    On Error Resume Next
    ws.Buttons.Delete
    On Error GoTo 0
    Boton ws, 8, 2, "AUTOPRUEBA", "Autoprueba"
    OcultarSensibles                          ' E-098: seguridad y auditoría no quedan a la vista del usuario
    ProtegerHojas                             ' Ola 1b: el usuario solo escribe en las hojas de HOJAS_EDITABLES
    InstalarNucleo = VentanaCreada()
    If InstalarNucleo Then Boton ws, 8, 4, "ABRIR APLICACIÓN", "AbrirApp"
End Function
Private Sub OcultarSensibles()
    ' Las hojas listadas en el parámetro HOJAS_OCULTAS quedan "muy ocultas" (no aparecen en Mostrar hojas). Límite: un libro
    ' de Excel no es una base segura; esto evita el acceso accidental, no el de alguien con acceso a las macros.
    Dim lista As String, nom As Variant, fp As Variant
    On Error Resume Next
    fp = Filas("PARAMETRO", "PAR_COD", "HOJAS_OCULTAS", "")
    If fp(0) > 0 Then lista = CStr(Hoja("PARAMETRO").Cells(fp(1), 2).Value)
    For Each nom In Split(lista, "|")
        If Trim(nom) <> "" Then ThisWorkbook.Worksheets(Trim(nom)).Visible = 2
    Next nom
    On Error GoTo 0
End Sub
Public Sub ProtegerHojas()
    ' Ola 1b: el usuario solo escribe en las hojas del parámetro HOJAS_EDITABLES; las macros del motor escriben en todas
    ' (UserInterfaceOnly). Límite dicho: la protección de Excel es disuasiva, no seguridad (OT-107 agregará la huella).
    Dim lista As String, ws As Object, fp As Variant
    On Error Resume Next
    fp = Filas("PARAMETRO", "PAR_COD", "HOJAS_EDITABLES", "")
    If fp(0) = 0 Then Exit Sub
    lista = "|" & CStr(Hoja("PARAMETRO").Cells(fp(1), 2).Value) & "|"
    For Each ws In ThisWorkbook.Worksheets
        If InStr(lista, "|" & ws.Name & "|") = 0 Then ws.Protect Password:="", UserInterfaceOnly:=True, AllowFiltering:=True
    Next ws
    On Error GoTo 0
End Sub
Public Sub Instalar()
    gSilencio = False
    If InstalarNucleo() Then
        Aviso "Instalado. Guarde el libro (.xlsm), ciérrelo y vuelva a abrirlo: la aplicación se abrirá sola."
    Else
        Aviso "La ventana no se pudo crear: active en Excel la confianza en el modelo de objetos de VBA y ejecute la macro CrearVentana (Alt+F8)."
    End If
End Sub
Public Function InstalarAuto() As String
    ' Para el instalador (instalar.bat): sin ventanas de mensaje; devuelve OK o el motivo
    gSilencio = True
    If InstalarNucleo() Then InstalarAuto = "OK" Else InstalarAuto = "SIN_CONFIANZA_VBA"
    gSilencio = False
End Function

' V4.1 §9.7 #6: la capa analítica identifica el paquete por PCA_PAQ; se resuelve al número de su primera propuesta pendiente
Private Function NumPropuesta(ByVal num As String, ByVal paq As String) As Variant
    Dim q As Long
    NumPropuesta = num
    If num <> "" Or paq = "" Then Exit Function
    For q = 2 To UltFila("PARAM_CAMBIO")
        If CStr(Hoja("PARAM_CAMBIO").Cells(q, 11).Value) = paq And (CStr(Hoja("PARAM_CAMBIO").Cells(q, 8).Value) = "P" Or CStr(Hoja("PARAM_CAMBIO").Cells(q, 8).Value) = "S") Then
            NumPropuesta = Hoja("PARAM_CAMBIO").Cells(q, 1).Value: Exit Function
        End If
    Next q
End Function

