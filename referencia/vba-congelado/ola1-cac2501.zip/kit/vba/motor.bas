Attribute VB_Name = "motor"
' ============================================================================
' MOTOR DEL SISTEMA DE COSTOS (prueba de concepto, metodología Dr. Tino Reyna)
' El código NO contiene lógica de negocio: interpreta las hojas TRX, TOP, OME,
' MET, MCA, FRM, CND, ALG y PAL. Semántica idéntica a motor_espejo.py.
' ============================================================================
Option Explicit
Public gUsuario As String, gPerfil As String, gSilencio As Boolean
Private gTraza As Boolean, gLogNum As Long, gPend As Boolean, gPendTrx As String, gPendLog As Long   ' TRAZA = S (en la trama o en PARAMETRO): cada FORMULA deja su cálculo en la hoja TRAZA
Public Const ERR_NEGOCIO As Long = 9001   ' error de negocio (regla, política, seguridad)
Private Const PROF_MAX As Long = 32       ' OT-052: niveles máximos de operaciones anidadas (SI/PARACADA/operación); idéntico en motor_espejo.py
Private gProf As Long
Private tK() As String, tV() As Variant, tN As Long
Private uSh() As String, uR() As Long, uC() As Long, uOld() As Variant, uN As Long
Private cSh() As String, cR() As Long, cN As Long
Private cacheFilas As Collection, cacheCol As Collection, cacheDatos() As Variant, cacheN As Long   ' solo rendimiento: la configuración no cambia durante una transacción
Private Const HOJAS_CONFIG As String = "|MCA|MET|OME|TOP|FRM|CND|PAL|TRX_CAMPO|MENSAJE|PERFIL_TRX|USUARIO|TRX|ALG|USUARIO_PERFIL|"

' ---------------- trama (variables de la transacción)
Public Sub TReset()
    tN = 0: ReDim tK(0 To 0): ReDim tV(0 To 0)
End Sub
Private Function TIdx(ByVal k As String) As Long
    Dim i As Long
    For i = 1 To tN
        If tK(i) = k Then TIdx = i: Exit Function
    Next i
    TIdx = 0
End Function
Public Sub TSet(ByVal k As String, ByVal v As Variant)
    Dim i As Long: i = TIdx(k)
    If i = 0 Then
        tN = tN + 1: ReDim Preserve tK(0 To tN): ReDim Preserve tV(0 To tN): i = tN: tK(i) = k
    End If
    tV(i) = v
End Sub
Public Function TGet(ByVal k As String) As Variant
    Dim i As Long: i = TIdx(k)
    If i = 0 Then Err.Raise ERR_NEGOCIO, "motor", "Variable no definida: " & k
    TGet = tV(i)
End Function
Public Function THas(ByVal k As String) As Boolean
    THas = (TIdx(k) > 0)
End Function
Public Function TOpc(ByVal k As String) As String
    ' Variable opcional de la trama: vacía si no viene
    If TIdx(k) > 0 Then TOpc = CStr(tV(TIdx(k)))
End Function

' ---------------- utilidades
Public Function Hoja(ByVal n As String) As Object
    Set Hoja = ThisWorkbook.Worksheets(n)
End Function
Private Function Vacio() As Variant
    ' devuelve un Variant vacío (Empty) sin usar la palabra clave, que LibreOffice no compila
End Function
Public Sub LimpiarCache()
    Set cacheFilas = New Collection: Set cacheCol = New Collection: cacheN = 0: ReDim cacheDatos(0 To 0)
End Sub
Public Function ColIdx(ByVal sh As String, ByVal c As String) As Long
    Dim ws As Object, j As Long, v As Variant
    If cacheCol Is Nothing Then LimpiarCache
    On Error Resume Next
    v = Vacio()
    v = cacheCol.Item(sh & "|" & c)
    If Err.Number = 0 And EsNum(v) Then   ' LibreOffice no da error con una clave inexistente
        On Error GoTo 0
        ColIdx = v: Exit Function
    End If
    Err.Clear
    On Error GoTo 0
    Set ws = Hoja(sh): j = 1
    Do While CStr(ws.Cells(1, j).Value) <> ""
        If CStr(ws.Cells(1, j).Value) = c Then ColIdx = j: cacheCol.Add j, sh & "|" & c: Exit Function
        j = j + 1
    Loop
    Err.Raise ERR_NEGOCIO, "motor", "Columna " & c & " no existe en " & sh
End Function
Public Function NCols(ByVal sh As String) As Long
    Dim ws As Object, j As Long: Set ws = Hoja(sh): j = 1
    Do While CStr(ws.Cells(1, j).Value) <> "": j = j + 1: Loop
    NCols = j - 1
End Function
Public Function UltFila(ByVal sh As String) As Long
    Dim ws As Object, r As Long: Set ws = Hoja(sh): r = 1
    Do While CStr(ws.Cells(r + 1, 1).Value) <> "": r = r + 1: Loop
    UltFila = r
End Function
Public Function EsNum(ByVal v As Variant) As Boolean
    Select Case VarType(v)
        Case vbInteger, vbLong, vbSingle, vbDouble, vbCurrency, vbDecimal: EsNum = True
        Case Else: EsNum = False
    End Select
End Function
Public Function Norm(ByVal v As Variant) As String
    If IsEmpty(v) Then Norm = "": Exit Function
    If EsNum(v) Then Norm = "#" & Format(CDbl(v), "0.000000000"): Exit Function
    Norm = Trim(CStr(v))
End Function
Public Function Num(ByVal v As Variant) As Double
    If IsEmpty(v) Then Num = 0: Exit Function
    If EsNum(v) Then Num = CDbl(v): Exit Function
    If Trim(CStr(v)) = "" Then Num = 0: Exit Function
    Num = Val(CStr(v))
End Function
Public Function Redondear(ByVal x As Double, ByVal n As Long) As Double
    Dim f As Double: f = 10 ^ n
    If x >= 0 Then Redondear = Int(x * f + 0.5 + 0.000000001) / f Else Redondear = -Int(-x * f + 0.5 + 0.000000001) / f
End Function
Public Function ParseValor(ByVal s As String) As Variant
    Dim t As String, i As Long, ch As String, puntos As Long, ok As Boolean
    t = Trim(s): ok = (Len(t) > 0)
    For i = 1 To Len(t)
        ch = Mid(t, i, 1)
        If ch = "." Then
            puntos = puntos + 1
        ElseIf ch = "-" And i = 1 Then
        ElseIf ch < "0" Or ch > "9" Then
            ok = False
        End If
    Next i
    If ok And puntos <= 1 Then ParseValor = Val(t) Else ParseValor = t
End Function
Public Sub CargarTrama(ByVal s As String)
    Dim partes() As String, i As Long, p As Long, v As String
    partes = Split(s, ";")
    For i = LBound(partes) To UBound(partes)
        p = InStr(partes(i), "=")
        If p > 0 Then
            v = Mid(partes(i), p + 1)                    ' I-4: %XX se decodifica antes de convertir el valor; %25 al final
            v = Replace(v, "%3B", ";"): v = Replace(v, "%7C", "|"): v = Replace(v, "%0A", vbLf): v = Replace(v, "%25", "%")
            TSet Trim(Left(partes(i), p - 1)), ParseValor(v)
        End If
    Next i
End Sub
Public Function Decodificar(ByVal v As String) As String
    ' I-4 (OT-102): inverso de canal_carga._val. %3B, %7C y %0A primero; %25 al FINAL (si no, «%253B» daría «;»)
    v = Replace(v, "%3B", ";")
    v = Replace(v, "%7C", "|")
    v = Replace(v, "%0A", vbLf)
    v = Replace(v, "%25", "%")
    Decodificar = v
End Function

' ---------------- registro de cambios (reversa y bitácora)
Private Sub SetCelda(ByVal sh As String, ByVal r As Long, ByVal c As Long, ByVal v As Variant)
    uN = uN + 1
    ReDim Preserve uSh(1 To uN): ReDim Preserve uR(1 To uN): ReDim Preserve uC(1 To uN): ReDim Preserve uOld(1 To uN)
    uSh(uN) = sh: uR(uN) = r: uC(uN) = c: uOld(uN) = Hoja(sh).Cells(r, c).Value
    Hoja(sh).Cells(r, c).Value = v
End Sub
Private Function NuevaFila(ByVal sh As String) As Long
    Dim r As Long: r = UltFila(sh) + 1
    cN = cN + 1: ReDim Preserve cSh(1 To cN): ReDim Preserve cR(1 To cN): cSh(cN) = sh: cR(cN) = r
    NuevaFila = r
End Function
Private Sub Restituir(ByVal cel As Object, ByVal v As Variant)
    ' Devuelve una cel a su valor anterior. Si era vacía, se borra: en LibreOffice asignar un valor vacío no la limpia (E-086)
    If IsEmpty(v) Then
        cel.ClearContents
    ElseIf CStr(v) = "" Then
        cel.ClearContents
    Else
        cel.Value = v
    End If
End Sub
Private Sub Reversar()
    Dim i As Long, ws As Object
    For i = uN To 1 Step -1
        Restituir Hoja(uSh(i)).Cells(uR(i), uC(i)), uOld(i)
    Next i
    For i = cN To 1 Step -1
        Set ws = Hoja(cSh(i))
        ws.Range(ws.Cells(cR(i), 1), ws.Cells(cR(i), NCols(cSh(i)))).ClearContents
    Next i
End Sub
Private Sub Bitacora(ByVal trx As String)
    Dim i As Long, r As Long, ws As Object, n As Long, sinB As String, cnt As Long, fp As Variant
    Set ws = Hoja("BITACORA")
    sinB = "|TRAZA|"
    fp = Filas("PARAMETRO", "PAR_COD", "SIN_BITACORA", "")
    If fp(0) > 0 Then sinB = CStr(Hoja("PARAMETRO").Cells(fp(1), 2).Value)
    For i = 1 To uN
        If uSh(i) <> "BITACORA" And InStr(sinB, "|" & uSh(i) & "|") = 0 Then   ' traza y datos derivados: se reconstruyen (EC-54)
            cnt = cnt + 1
            r = UltFila("BITACORA") + 1: n = r - 1
            ws.Cells(r, 1).Value = n: ws.Cells(r, 2).Value = trx: ws.Cells(r, 3).Value = gUsuario
            ws.Cells(r, 4).Value = uSh(i): ws.Cells(r, 5).Value = uR(i)
            ws.Cells(r, 6).Value = CStr(Hoja(uSh(i)).Cells(1, uC(i)).Value)
            ws.Cells(r, 7).Value = uOld(i): ws.Cells(r, 8).Value = Hoja(uSh(i)).Cells(uR(i), uC(i)).Value
            ws.Cells(r, 9).Value = gLogNum
        End If
    Next i
    If gLogNum > 0 Then Hoja("LOG_TRX").Cells(gLogNum + 1, 6).Value = cnt   ' el log guarda cuántos cambios hizo la transacción
End Sub

' ---------------- catálogo único de mensajes (DBD p. 26)
Public Function Mensaje(ByVal cod As String) As String
    Dim f As Variant
    f = Filas("MENSAJE", "MSG_COD", cod, "")
    If f(0) = 0 Then
        Mensaje = cod
    Else
        Mensaje = CStr(Hoja("MENSAJE").Cells(f(1), 2).Value)
    End If
End Function

' ---------------- sello de modo (OT-045, T-142): sin texto fijo; lo dicen PARAMETRO y MENSAJE
' MODO_SISTEMA en PARAMETRO elige el sello: si existe el mensaje MSG-SELLO-<valor> se muestra; si no (p. ej. OFICIAL), no hay sello.
Public Function Sello() As String
    Dim fp As Variant, fm As Variant, modo As String
    Sello = ""
    fp = Filas("PARAMETRO", "PAR_COD", "MODO_SISTEMA", "")
    If fp(0) = 0 Then Exit Function
    modo = UCase(Trim(CStr(Celda("PARAMETRO", fp(1), "PAR_VAL"))))
    fm = Filas("MENSAJE", "MSG_COD", "MSG-SELLO-" & modo, "")
    If fm(0) > 0 Then Sello = Mensaje("MSG-SELLO-" & modo)
End Function

' ---------------- lectura de configuración
Public Function Filas(ByVal sh As String, ByVal col As String, ByVal v As Variant, ByVal ordCol As String) As Variant
    Dim ws As Object, c As Long, oc As Long, r As Long, n As Long, a() As Long, i As Long, j As Long, t As Long, clave As String, enCache As Boolean, x As Variant
    enCache = (InStr(HOJAS_CONFIG, "|" & sh & "|") > 0)
    If enCache Then
        If cacheFilas Is Nothing Then LimpiarCache
        clave = sh & "|" & col & "|" & Norm(v) & "|" & ordCol
        On Error Resume Next
        x = Vacio()
        x = cacheFilas.Item(clave)
        If Err.Number = 0 And EsNum(x) Then   ' la colección guarda el índice; el arreglo está en cacheDatos
            On Error GoTo 0
            Filas = cacheDatos(CLng(x)): Exit Function
        End If
        Err.Clear
        On Error GoTo 0
    End If
    Set ws = Hoja(sh): c = ColIdx(sh, col): If ordCol <> "" Then oc = ColIdx(sh, ordCol)
    ReDim a(0 To 0)
    For r = 2 To UltFila(sh)
        If Norm(ws.Cells(r, c).Value) = Norm(v) Then n = n + 1: ReDim Preserve a(0 To n): a(n) = r
    Next r
    If oc > 0 Then
        For i = 2 To n
            t = a(i): j = i - 1
            Do While j >= 1
                If Num(ws.Cells(a(j), oc).Value) <= Num(ws.Cells(t, oc).Value) Then Exit Do
                a(j + 1) = a(j): j = j - 1
            Loop
            a(j + 1) = t
        Next i
    End If
    a(0) = n
    If enCache Then
        cacheN = cacheN + 1: ReDim Preserve cacheDatos(0 To cacheN): cacheDatos(cacheN) = a
        cacheFilas.Add cacheN, clave
    End If
    Filas = a
End Function
Private Function Celda(ByVal sh As String, ByVal r As Long, ByVal col As String) As Variant
    Celda = Hoja(sh).Cells(r, ColIdx(sh, col)).Value
End Function
Private Function Valor(ByVal ori As String, ByVal v As Variant) As Variant
    Select Case ori
        Case "VAR": Valor = TGet(CStr(v))
        Case "VAROPC": If THas(CStr(v)) Then Valor = TGet(CStr(v)) Else Valor = ""
        Case "LIT": Valor = v
        Case "SIS"
            If CStr(v) = "#USR" Then Valor = gUsuario Else Err.Raise ERR_NEGOCIO, "motor", "Origen de sistema desconocido: " & v
        Case Else: Err.Raise ERR_NEGOCIO, "motor", "Origen desconocido: " & ori
    End Select
End Function
Private Function Plantilla(ByVal c As String) As String
    Dim a As Long, b As Long
    Do While InStr(c, "{") > 0
        a = InStr(c, "{"): b = InStr(c, "}")
        c = Left(c, a - 1) & CStr(TGet(Mid(c, a + 1, b - a - 1))) & Mid(c, b + 1)
    Loop
    Plantilla = c
End Function

' ---------------- ejecución
Public Function EjecutarTRX(ByVal trx As String, Optional ByVal lineas As Variant) As String
    ' Un evento = una transacción. lineas: arreglo de tramas de línea ("REC=..;CANT=.."). Las operaciones de
    ' nivel U (TOP_NIV) corren solo en la 1.ª línea y lo que crean (p. ej. EVE_NUM) se hereda a las demás.
    ' Si cualquier línea falla, se revierte el evento completo.
    Dim ops As Variant, i As Long, perm As Variant, ok As Boolean, k As Long, nL As Long
    Dim bK() As String, bV() As Variant, bN As Long, hK() As String, hV() As Variant, hN As Long
    Dim aK() As String, aV() As Variant, aN As Long, j As Long, cambia As Boolean, niv As String, q As Long
    Dim logR As Long
    RecuperarPendientes                       ' re-arranque: nada nuevo se aplica sobre un pendiente sin confirmar
    uN = 0: cN = 0: gProf = 0
    LimpiarCache
    logR = LogInicia(trx): gLogNum = logR - 1: gPend = False
    On Error GoTo Fallo
    gTraza = TrazaActiva()
    TSet "TRX", trx: TSet "USR", gUsuario
    DerivarCabecera                           ' EC-23: empresa del usuario y periodo de la fecha, si no vienen
    ok = Permiso(trx)
    If Not ok Then Err.Raise ERR_NEGOCIO, "motor", Mensaje("MSG-SEG") & " (" & gPerfil & " -> " & trx & ")"
    ops = Filas("TOP", "TOP_TRX", trx, "TOP_SEC")
    If ops(0) = 0 Then Err.Raise ERR_NEGOCIO, "motor", "Transacción sin protocolo: " & trx
    If IsMissing(lineas) Then nL = 1 Else nL = UBound(lineas) - LBound(lineas) + 1
    If nL < 1 Then nL = 1
    TCopia bK, bV, bN
    For k = 1 To nL
        TRestaura bK, bV, bN
        If Not IsMissing(lineas) Then CargarTrama CStr(lineas(LBound(lineas) + k - 1))
        For j = 1 To hN: TSet hK(j), hV(j): Next j
        TSet "LIN_NUM", k
        For i = 1 To ops(0)
            niv = UCase(CStr(Celda("TOP", ops(i), "TOP_NIV")))
            If niv = "U" Then
                If k = 1 Then
                    TCopia aK, aV, aN
                    EjecutarOPN CStr(Celda("TOP", ops(i), "TOP_OPN"))
                    For j = 1 To tN
                        cambia = True
                        For q = 1 To aN
                            If aK(q) = tK(j) Then cambia = (CStr(aV(q)) <> CStr(tV(j))): Exit For
                        Next q
                        If cambia Then hN = hN + 1: ReDim Preserve hK(1 To hN): ReDim Preserve hV(1 To hN): hK(hN) = tK(j): hV(hN) = tV(j)
                    Next j
                End If
            Else
                EjecutarOPN CStr(Celda("TOP", ops(i), "TOP_OPN"))
            End If
        Next i
        Alarmas trx                         ' OT-072 (AL-1): tras el HECHO de la linea; solo escribe ALERTA, nunca lo bloquea
    Next k
    LogEstado logR, "O", ""                 ' listo para aplicar (DBD p. 26)
    If THas("MODO") Then
        If UCase(CStr(TGet("MODO"))) = "PREVIA" Then
            Bitacora trx                                     ' queda reconstruible aunque se pierda la memoria
            gPend = True: gPendTrx = trx: gPendLog = logR   ' espera Confirmar o Deshacer
            EjecutarTRX = "OK"
            Exit Function
        End If
    End If
    Bitacora trx
    LogEstado logR, "A", ""
    EjecutarTRX = "OK"
    Exit Function
Fallo:
    Dim msg As String: msg = Err.Description
    On Error Resume Next
    Reversar
    LogEstado logR, "E", msg
    EjecutarTRX = "ERROR: " & msg
End Function
Private Function ExisteHoja(ByVal nom As String) As Boolean
    Dim hx As Object
    For Each hx In ThisWorkbook.Worksheets
        If hx.Name = nom Then ExisteHoja = True: Exit Function
    Next hx
End Function
Private Sub Alarmas(ByVal trx As String)
    ' OT-072 (AL-1, ESPEC_ETAPA2B 3): reglas de negocio de Tino, condiciones simples sobre variables de la PROPIA transaccion.
    ' Corre DESPUES del hecho de la linea; su unica accion es escribir en ALERTA (nunca modifica ni bloquea el hecho, I3).
    ' Evalua a lo sumo ALARMAS_MAX_TRX reglas activas y vigentes (en el orden de la hoja); sin la tabla o sin el parametro no evalua nada.
    ' Una regla que no se puede evaluar (variable ausente de la trama, prefijo MVIG_, umbral inexistente o no numerico) se omite.
    ' Igual que alarmas de motor_espejo.py (P19).
    Dim fp As Variant, fr As Variant, fu As Variant, i As Long, mx As Double, nr As Long, fch As Double
    Dim vr As String, va As Variant, vb As Variant, k As Integer, sale As Boolean
    Dim perA As Variant, empA As Variant, refA As Variant, linA As Variant, codA As String, fa As Long, rr As Long
    If Not ExisteHoja("REGLA_ALARMA") Then Exit Sub
    If Not ExisteHoja("ALERTA") Then Exit Sub
    fp = Filas("PARAMETRO", "PAR_COD", "ALARMAS_MAX_TRX", "")
    If fp(0) = 0 Then Exit Sub
    mx = Num(Hoja("PARAMETRO").Cells(fp(1), 2).Value)
    If mx <= 0 Then Exit Sub
    If Not THas("PER") Then Exit Sub
    If Not THas("EMP") Then Exit Sub
    perA = TGet("PER"): empA = TGet("EMP")
    If CStr(perA) = "" Or CStr(empA) = "" Then Exit Sub        ' sin periodo y empresa no hay clave de ALERTA
    If THas("FECHA") Then fch = Num(TGet("FECHA"))
    fr = Filas("REGLA_ALARMA", "RAL_TRX", trx, "")
    For i = 1 To fr(0)
        If UCase(CStr(Celda("REGLA_ALARMA", fr(i), "RAL_ACTIVA"))) = "S" And Not (Num(Celda("REGLA_ALARMA", fr(i), "RAL_DESDE")) > fch) Then
            If nr >= mx Then Exit For
            nr = nr + 1
            vr = CStr(Celda("REGLA_ALARMA", fr(i), "RAL_VAR"))
            vb = UmbralParametro(CStr(Celda("REGLA_ALARMA", fr(i), "RAL_PARM")), CStr(empA))   ' D1 (Ola 1): el umbral vive en PARAMETRO
            If Left(vr, 5) <> "MVIG_" And THas(vr) And CStr(vb) <> "" Then
                va = TGet(vr)
                If CStr(vb) <> "" And (EsNum(va) Or ParesNum(va)) And (EsNum(vb) Or ParesNum(vb)) Then
                    k = Compara(Num(va), Num(vb))
                    Select Case CStr(Celda("REGLA_ALARMA", fr(i), "RAL_OPELOG"))
                        Case "EQ": sale = (k = 0)
                        Case "NE": sale = (k <> 0)
                        Case "GT": sale = (k > 0)
                        Case "GE": sale = (k >= 0)
                        Case "LT": sale = (k < 0)
                        Case "LE": sale = (k <= 0)
                        Case Else: sale = False
                    End Select
                    If sale Then
                        codA = CStr(Celda("REGLA_ALARMA", fr(i), "RAL_COD"))
                        If THas("EVE_NUM") Then refA = TGet("EVE_NUM") Else refA = trx
                        linA = TGet("LIN_NUM")
                        fa = 0
                        For rr = 2 To UltFila("ALERTA")
                            If Norm(Celda("ALERTA", rr, "ALE_PER")) = Norm(perA) And Norm(Celda("ALERTA", rr, "ALE_EMP")) = Norm(empA) And Norm(Celda("ALERTA", rr, "ALE_TIPO")) = Norm(codA) And Norm(Celda("ALERTA", rr, "ALE_REF")) = Norm(refA) And Norm(Celda("ALERTA", rr, "ALE_REF2")) = Norm(linA) Then fa = rr: Exit For
                        Next rr
                        If fa = 0 Then
                            fa = NuevaFila("ALERTA")
                            SetCelda "ALERTA", fa, 1, perA: SetCelda "ALERTA", fa, 2, empA: SetCelda "ALERTA", fa, 3, codA
                            SetCelda "ALERTA", fa, 4, refA: SetCelda "ALERTA", fa, 5, linA
                        End If
                        SetCelda "ALERTA", fa, ColIdx("ALERTA", "ALE_VAL"), Num(va)
                        SetCelda "ALERTA", fa, ColIdx("ALERTA", "ALE_UMB"), Num(vb)
                    End If
                End If
            End If
        End If
    Next i
End Sub
Public Function ConfirmarPendiente() As String
    ' Arrepentimiento (DBD p. 26): confirmar deja definitivo lo que estaba listo para aplicar
    If Not gPend Then ConfirmarPendiente = "ERROR: " & Mensaje("MSG-SINPEND"): Exit Function
    LogEstado gPendLog, "A", ""                      ' la bitácora ya se escribió al quedar listo
    gPend = False
    ConfirmarPendiente = "OK"
End Function
Public Function DeshacerPendiente() As String
    ' Arrepentimiento (DBD p. 26): deshacer revierte todos los cambios de la transacción en espera
    If Not gPend Then DeshacerPendiente = "ERROR: " & Mensaje("MSG-SINPEND"): Exit Function
    Reversar
    LogEstado gPendLog, "R", "Deshecho por el usuario"
    gPend = False
    DeshacerPendiente = "OK"
End Function
Public Sub RecuperarPendientes()
    ' Re-arranque (DBD §4.2: el log con estados permite recuperar). Toda transacción que quedó en O ("listo para
    ' aplicar") sin Confirmar ni Deshacer se revierte: desde la memoria si aún existe; si no, desde la bitácora.
    Dim r As Long, b As Long, n As Long, ws As Object, tb As String, fl As Long, cl As String
    If gPend Then
        Reversar
        LogEstado gPendLog, "R", Mensaje("MSG-REANUDA")
        gPend = False
    End If
    Set ws = Hoja("BITACORA")
    For r = 2 To UltFila("LOG_TRX")
        If CStr(Hoja("LOG_TRX").Cells(r, 4).Value) = "O" Then
            n = r - 1
            For b = UltFila("BITACORA") To 2 Step -1
                If Num(ws.Cells(b, 9).Value) = n Then
                    tb = CStr(ws.Cells(b, 4).Value): fl = CLng(ws.Cells(b, 5).Value): cl = CStr(ws.Cells(b, 6).Value)
                    Restituir Hoja(tb).Cells(fl, ColIdx(tb, cl)), ws.Cells(b, 7).Value
                End If
            Next b
            LogEstado r, "R", Mensaje("MSG-REANUDA")
        End If
    Next r
End Sub
Public Sub Reiniciar()
    ' Simula cerrar Excel con una transacción en espera: se pierde la memoria y se recupera desde el log y la bitácora
    gPend = False: uN = 0: cN = 0
    RecuperarPendientes
End Sub
Public Function HayPendiente() As Boolean
    HayPendiente = gPend
End Function
Private Function LogInicia(ByVal trx As String) As Long
    ' Registro log (DBD §4.2.4): estados I iniciado, O listo, A actualizado, E abortado. Se escribe FUERA de la
    ' reversa, así que sobrevive a un error y deja rastro de toda transacción intentada.
    Dim r As Long
    r = UltFila("LOG_TRX") + 1
    With Hoja("LOG_TRX")
        .Cells(r, 1).Value = r - 1: .Cells(r, 2).Value = trx: .Cells(r, 3).Value = gUsuario: .Cells(r, 4).Value = "I": .Cells(r, 6).Value = 0
    End With
    LogInicia = r
End Function
Private Sub LogEstado(ByVal r As Long, ByVal est As String, ByVal msg As String)
    Hoja("LOG_TRX").Cells(r, 4).Value = est
    If msg <> "" Then Hoja("LOG_TRX").Cells(r, 5).Value = msg
End Sub
' ---------------- gobierno de parámetros (doble control): un cambio es un evento con estados P -> A / R
Public Function PuedeOperar(ByVal op As String) As Boolean
    ' Ola 1b: la pantalla OPERAR MES valida permisos con la misma regla que el motor (sin ejecutar nada)
    PuedeOperar = Permiso(op)
End Function
Private Function Permiso(ByVal op As String) As Boolean
    ' Relación usuario-perfil (DBD §4.3.1): basta que uno de los perfiles del usuario esté autorizado.
    Dim perm As Variant, i As Long, up As Variant, k As Long, pf As String
    up = Filas("USUARIO_PERFIL", "UPE_USR", gUsuario, "")
    For k = 0 To up(0)
        If k = 0 Then
            If up(0) > 0 Then GoTo SigPerfil
            pf = gPerfil
        Else
            pf = CStr(Celda("USUARIO_PERFIL", up(k), "UPE_PERFIL"))
        End If
        perm = Filas("PERFIL_TRX", "PTX_PERFIL", pf, "")
        For i = 1 To perm(0)
            If CStr(Celda("PERFIL_TRX", perm(i), "PTX_TRX")) = op Then Permiso = True: Exit Function
        Next i
SigPerfil:
    Next k
End Function
Private Sub DerivarCabecera()
    ' No se digita lo que el sistema ya sabe (MCD §4.2.6): la empresa sale del usuario; el periodo, de la fecha.
    Dim fu As Variant, r As Long, wp As Object, fe As Double
    If Not THas("EMP") Then
        fu = Filas("USUARIO", "USU_COD", gUsuario, "")
        If fu(0) > 0 Then
            If CStr(Hoja("USUARIO").Cells(fu(1), ColIdx("USUARIO", "USU_EMP")).Value) <> "" Then TSet "EMP", CStr(Hoja("USUARIO").Cells(fu(1), ColIdx("USUARIO", "USU_EMP")).Value)
        End If
    End If
    If Not THas("PER") And THas("FECHA") And THas("EMP") Then
        Set wp = Hoja("PERIODO"): fe = Num(TGet("FECHA"))
        For r = 2 To UltFila("PERIODO")
            If Norm(wp.Cells(r, ColIdx("PERIODO", "PER_EMP")).Value) = Norm(TGet("EMP")) Then
                If Num(wp.Cells(r, ColIdx("PERIODO", "PER_INI")).Value) <= fe And fe <= Num(wp.Cells(r, ColIdx("PERIODO", "PER_FIN")).Value) Then
                    TSet "PER", CStr(wp.Cells(r, ColIdx("PERIODO", "PER_COD")).Value)
                    Exit For
                End If
            End If
        Next r
        Tardio                                        ' I-3: solo cuando el periodo sale de la fecha (un PER explícito cerrado se rechaza como antes)
    End If
End Sub
Private Sub Tardio()
    ' I-3 (OT-102): FECHA en un periodo CERRADO y transacción en TARDIO_TRX -> el evento va al primer periodo abierto (PER) con
    ' PER_REF = periodo de la fecha; EVE_FEC conserva la fecha real. El aviso queda en LOG_TRX; el retorno sigue «OK» (H-2).
    Dim f As Variant, wp As Object, r As Long, pe As Long, mejor As Long, ini As Double, lst As String
    If Not THas("PER") Or Not THas("EMP") Then Exit Sub
    Set wp = Hoja("PERIODO")
    For r = 2 To UltFila("PERIODO")
        If CStr(wp.Cells(r, ColIdx("PERIODO", "PER_COD")).Value) = CStr(TGet("PER")) And Norm(wp.Cells(r, ColIdx("PERIODO", "PER_EMP")).Value) = Norm(TGet("EMP")) Then pe = r
    Next r
    If pe = 0 Then Exit Sub
    If CStr(wp.Cells(pe, ColIdx("PERIODO", "PER_EST")).Value) <> "C" Then Exit Sub
    f = Filas("PARAMETRO", "PAR_COD", "TARDIO_TRX", "")
    If f(0) = 0 Then Exit Sub
    lst = "|" & Replace(CStr(Hoja("PARAMETRO").Cells(f(1), ColIdx("PARAMETRO", "PAR_VAL")).Value), " ", "") & "|"
    If InStr(lst, "|" & CStr(TGet("TRX")) & "|") = 0 Then Exit Sub
    For r = 2 To UltFila("PERIODO")
        If Norm(wp.Cells(r, ColIdx("PERIODO", "PER_EMP")).Value) = Norm(TGet("EMP")) And CStr(wp.Cells(r, ColIdx("PERIODO", "PER_EST")).Value) = "A" Then
            If mejor = 0 Or Num(wp.Cells(r, ColIdx("PERIODO", "PER_INI")).Value) < ini Then mejor = r: ini = Num(wp.Cells(r, ColIdx("PERIODO", "PER_INI")).Value)
        End If
    Next r
    If mejor = 0 Then Exit Sub
    TSet "PER_REF", CStr(TGet("PER"))
    TSet "PER", CStr(wp.Cells(mejor, ColIdx("PERIODO", "PER_COD")).Value)
    If gLogNum > 0 Then Hoja("LOG_TRX").Cells(gLogNum + 1, 5).Value = "HECHO TARDÍO de " & CStr(TGet("PER_REF"))
End Sub
Private Function ValidarDato(ByVal tabla As String, ByVal fila As Long, ByVal col As String, ByVal dato As Variant) As String
    ' Gobierno de MANT-PARM (E-086): clase de la tabla (EC-12), rango del parámetro (EC-15), integridad de referencia (EC-16)
    Dim f As Variant, tt As String, r As Long, wr As Object, mn As String, mx As String, v As Double
    f = Filas("TABLAS_LOGICAS", "Tabla", tabla, "")
    If f(0) > 0 Then tt = CStr(Hoja("TABLAS_LOGICAS").Cells(f(1), 2).Value)
    If tt = "HISTORICO" Or tt = "PARQUE" Or tt = "PARQUE-SEMILLA" Or tt = "CONFIG" Then ValidarDato = Mensaje("MSG-SOLOLECT"): Exit Function
    If tabla = "PARAMETRO" And col = "PAR_VAL" And fila > 0 And Trim(CStr(dato)) <> "" Then
        v = Num(dato)                                   ' conversión propia (independiente de la configuración regional)
        mn = CStr(Hoja("PARAMETRO").Cells(fila, ColIdx("PARAMETRO", "PAR_MIN")).Value)
        mx = CStr(Hoja("PARAMETRO").Cells(fila, ColIdx("PARAMETRO", "PAR_MAX")).Value)
        If mn <> "" Then
            If v < Num(mn) Then ValidarDato = Mensaje("MSG-RANGO"): Exit Function
        End If
        If mx <> "" Then
            If v > Num(mx) Then ValidarDato = Mensaje("MSG-RANGO"): Exit Function
        End If
    End If
    If CStr(dato) = "" Then Exit Function
    Set wr = Hoja("DATO_REF")
    For r = 2 To UltFila("DATO_REF")
        If CStr(wr.Cells(r, 1).Value) = tabla And CStr(wr.Cells(r, 2).Value) = col Then
            f = Filas(CStr(wr.Cells(r, 3).Value), CStr(wr.Cells(r, 4).Value), dato, "")
            If f(0) = 0 Then ValidarDato = Mensaje("MSG-REF") & " (" & col & " = " & CStr(dato) & ")": Exit Function
        End If
    Next r
End Function
Private Function FilaClave(ByVal tabla As String, ByVal clave As Variant) As Long
    ' I-4 (OT-102): clave compuesta «v1|v2|…» contra las columnas de CLAVE_COMPUESTA (derivado del DBD); simple: columna 1, como antes
    Dim r As Long, cols() As String, partes() As String, i As Long, ok As Boolean, cc As String
    cc = ColsClave(tabla)
    If cc <> "" Then
        cols = Split(cc, ","): partes = Split(clave & "", "|")
        If UBound(partes) = UBound(cols) - 1 Then           ' D12: clave sin empresa = fila comun "*"
            For i = 0 To UBound(cols)
                If Right(Trim(cols(i)), 4) = "_EMP" Then partes = Split(ClaveConComun(clave & "", i), "|"): Exit For
            Next i
        End If
        If UBound(partes) <> UBound(cols) Then Exit Function
        For r = 2 To UltFila(tabla)
            ok = True
            For i = 0 To UBound(cols)
                If Norm(Hoja(tabla).Cells(r, ColIdx(tabla, Trim(cols(i)))).Value) <> Norm(partes(i)) Then ok = False: Exit For
            Next i
            If ok Then FilaClave = r: Exit Function
        Next r
        Exit Function
    End If
    For r = 2 To UltFila(tabla)
        If Norm(Hoja(tabla).Cells(r, 1).Value) = Norm(clave) Then FilaClave = r: Exit Function
    Next r
End Function
Private Function CompletarClave(ByVal tabla As String, ByVal clave As Variant, ByRef e As String) As String
    ' I-5: en una tabla de cada empresa el usuario no escribe la empresa: se completa con la suya; otra empresa -> MSG-EMP
    Dim cc As String, cols() As String, partes() As String, i As Long, ie As Long, emp As String, fu As Variant, s As String
    CompletarClave = clave & "": cc = ColsClave(tabla): If cc = "" Then Exit Function
    cols = Split(cc, ","): ie = -1
    For i = 0 To UBound(cols)
        If Right(Trim(cols(i)), 4) = "_EMP" Then ie = i
    Next i
    If ie < 0 Then Exit Function
    fu = Filas("USUARIO", "USU_COD", gUsuario, "")
    If fu(0) > 0 Then emp = CStr(Hoja("USUARIO").Cells(fu(1), ColIdx("USUARIO", "USU_EMP")).Value)
    partes = Split(clave & "", "|")
    If UBound(partes) = UBound(cols) - 1 Then
        s = ""
        For i = 0 To UBound(cols)
            If i > 0 Then s = s & "|"
            If i = ie Then
                s = s & emp
            ElseIf i < ie Then
                s = s & partes(i)
            Else
                s = s & partes(i - 1)
            End If
        Next i
        CompletarClave = s
        If FilaClave(tabla, s) = 0 Then CompletarClave = clave & ""   ' D12: sin valor propio -> clave sin empresa = el comun "*"
    ElseIf UBound(partes) = UBound(cols) Then
        If Norm(partes(ie)) <> Norm(emp) And Norm(partes(ie)) <> "*" Then e = Mensaje("MSG-EMP")
    End If
End Function
Private Function ClaveConComun(ByVal clave As String, ByVal ie As Long) As String
    ' D12: inserta "*" (empresa comun) en la posicion ie de una clave a la que le falta la empresa
    Dim p() As String, i As Long, s As String
    p = Split(clave, "|")
    For i = 0 To UBound(p) + 1
        If i > 0 Then s = s & "|"
        If i = ie Then
            s = s & "*"
        ElseIf i < ie Then
            s = s & p(i)
        Else
            s = s & p(i - 1)
        End If
    Next i
    ClaveConComun = s
End Function
Private Function ColsClave(ByVal tabla As String) As String
    ' «COL1,COL2» si la tabla tiene clave compuesta según PARAMETRO CLAVE_COMPUESTA («TABLA:COL1,COL2|…»); vacío si no
    Dim f As Variant, items() As String, i As Long, p As Long
    f = Filas("PARAMETRO", "PAR_COD", "CLAVE_COMPUESTA", "")
    If f(0) = 0 Then Exit Function
    items = Split(CStr(Hoja("PARAMETRO").Cells(f(1), ColIdx("PARAMETRO", "PAR_VAL")).Value), "|")
    For i = 0 To UBound(items)
        p = InStr(items(i), ":")
        If p > 0 Then
            If Trim(Left(items(i), p - 1)) = tabla Then
                If UBound(Split(Mid(items(i), p + 1), ",")) > 0 Then ColsClave = Mid(items(i), p + 1)
                Exit Function
            End If
        End If
    Next i
End Function
Public Function ProponerCambio(ByVal tabla As String, ByVal clave As Variant, ByVal col As String, ByVal nuevo As Variant, Optional ByVal motivo As String = "", Optional ByVal paq As String = "", Optional ByVal prop As String = "") As String
    Dim r As Long, n As Long, e As String, partes() As String, j As Long
    On Error GoTo FalloP                              ' ningún error abre un diálogo: vuelve como mensaje
    RecuperarPendientes
    LimpiarCache
    If Not Permiso("MANT-PARM") Then ProponerCambio = "ERROR: " & Mensaje("MSG-SEG") & " (" & gPerfil & " -> MANT-PARM)": Exit Function
    If Trim(motivo) = "" Then ProponerCambio = "ERROR: " & Mensaje("MSG-MOTIVO"): Exit Function
    e = ValidarDato(tabla, 0, "", "")                 ' I-4: la clase de la tabla (solo lectura) se valida antes de buscar la clave
    If e <> "" Then ProponerCambio = "ERROR: " & e: Exit Function
    If col = "(NUEVA)" Then
        r = 0
        partes = Split(CStr(nuevo), "|")
        For j = 0 To UBound(partes)
            If e = "" And j < NCols(tabla) Then e = ValidarDato(tabla, 0, CStr(Hoja(tabla).Cells(1, j + 1).Value), ParseValor(partes(j)))
        Next j
    Else
        clave = CompletarClave(tabla, clave, e)
        If e <> "" Then ProponerCambio = "ERROR: " & e: Exit Function
        r = FilaClave(tabla, clave)
        If r = 0 Then ProponerCambio = "ERROR: " & Mensaje("MSG-CLAVE"): Exit Function
        e = ValidarDato(tabla, r, col, nuevo)
    End If
    If e <> "" Then ProponerCambio = "ERROR: " & e: Exit Function
    If prop <> "" And Not TieneCol("PARAM_CAMBIO", "PCA_PROP") Then ProponerCambio = "ERROR: la base no tiene PCA_PROP (falta la estructura de I-2)": Exit Function
    n = UltFila("PARAM_CAMBIO") + 1
    With Hoja("PARAM_CAMBIO")
        .Cells(n, 1).Value = n - 1: .Cells(n, 2).Value = tabla: .Cells(n, 3).Value = clave: .Cells(n, 4).Value = col
        If r > 0 Then .Cells(n, 5).Value = Hoja(tabla).Cells(r, ColIdx(tabla, col)).Value
        .Cells(n, 6).Value = nuevo: .Cells(n, 7).Value = gUsuario: .Cells(n, 8).Value = "P"
        .Cells(n, 10).Value = motivo: .Cells(n, 11).Value = paq
        If prop <> "" Then .Cells(n, ColIdx("PARAM_CAMBIO", "PCA_PROP")).Value = prop   ' I-2: entrada del catálogo PROPUESTA
    End With
    ProponerCambio = "OK"
    Exit Function
FalloP:
    ProponerCambio = "ERROR: " & Err.Description
End Function
Private Function EsNivel1(ByVal wc As Object, ByVal q As Long) As Boolean
    ' V4.1 R-71: solo el actor SISTEMA puede aprobar lo que propuso, y solo un PAR_VAL de un parámetro con PAR_DUENO = SISTEMA y PAR_PROT = N
    Dim r As Long, p As Long, pr As String
    EsNivel1 = False
    If gUsuario <> "SISTEMA" Then Exit Function
    If CStr(wc.Cells(q, 2).Value) <> "PARAMETRO" Or CStr(wc.Cells(q, 4).Value) <> "PAR_VAL" Then Exit Function
    r = FilaClave("PARAMETRO", wc.Cells(q, 3).Value)
    If r = 0 Then Exit Function
    If CStr(Hoja("PARAMETRO").Cells(r, ColIdx("PARAMETRO", "PAR_DUENO")).Value) <> "SISTEMA" Then Exit Function
    If CStr(Hoja("PARAMETRO").Cells(r, ColIdx("PARAMETRO", "PAR_PROT")).Value) <> "N" Then Exit Function
    If UCase(Left(CStr(wc.Cells(q, 10).Value), 9)) = "REVERSION" Then Exit Function      ' I-2 (V8): una reversión la aprueba una persona
    If TieneCol("PARAM_CAMBIO", "PCA_PROP") Then
        pr = CStr(wc.Cells(q, ColIdx("PARAM_CAMBIO", "PCA_PROP")).Value)
        If pr <> "" Then                                                          ' I-2 (V8): solo entradas de PROPUESTA con nivel 1
            If Not ExisteHoja("PROPUESTA") Then Exit Function
            p = FilaClave("PROPUESTA", pr)
            If p = 0 Then Exit Function
            If Num(Hoja("PROPUESTA").Cells(p, ColIdx("PROPUESTA", "PRO_NIVEL")).Value) <> 1 Then Exit Function
        End If
    End If
    EsNivel1 = True
End Function
Private Function TieneCol(ByVal sh As String, ByVal c As String) As Boolean
    Dim ws As Object, j As Long
    If Not ExisteHoja(sh) Then Exit Function
    Set ws = Hoja(sh): j = 1
    Do While CStr(ws.Cells(1, j).Value) <> ""
        If CStr(ws.Cells(1, j).Value) = c Then TieneCol = True: Exit Function
        j = j + 1
    Loop
End Function
Public Function Seguim(ByVal ref As Variant, ByVal obj As String, ByVal per As String, ByVal pred As Variant, ByVal rea As Variant, _
                       ByVal er As Variant, ByVal est As String, ByVal regla As String) As String
    ' I-2 (OT-098 I2-b): seguimiento de una decisión. Escribe o reemplaza la fila EST_DECISION de REF (= PCA_NUM).
    ' Solo perfil autorizado (AUTONOMO); el PCA debe existir y estar en A; REAL y ERR vacíos solo con ESTADO = PENDIENTE. Espejo: Motor.seguim.
    Dim r As Long, q As Long, p As Long, i As Long, cols As Variant, vals As Variant, ws As Object
    RecuperarPendientes
    uN = 0: cN = 0
    LimpiarCache
    On Error GoTo Fallo
    If Not Permiso("@SEGUIM") Then Err.Raise ERR_NEGOCIO, "motor", Mensaje("MSG-SEG") & " (" & gPerfil & " -> @SEGUIM)"
    If est <> "PENDIENTE" And est <> "MEDIDO" And est <> "SIN_MEDICION" Then Err.Raise ERR_NEGOCIO, "motor", "ESTADO " & est & " fuera de dominio (PENDIENTE, MEDIDO, SIN_MEDICION)"
    p = FilaClave("PARAM_CAMBIO", ref)
    If p = 0 Then Err.Raise ERR_NEGOCIO, "motor", "PCA_NUM " & CStr(ref) & " no existe"
    If CStr(Hoja("PARAM_CAMBIO").Cells(p, 8).Value) <> "A" Then Err.Raise ERR_NEGOCIO, "motor", "PCA_NUM " & CStr(ref) & " no está aprobado"
    If Not EsNum(pred) Then Err.Raise ERR_NEGOCIO, "motor", "PRED no numérico (" & CStr(pred) & ")"      ' LO-3: la trama llega por ParseValor
    If CStr(rea) = "" Or CStr(er) = "" Then
        If est <> "PENDIENTE" Then Err.Raise ERR_NEGOCIO, "motor", "REAL y ERR vacíos solo se admiten con ESTADO = PENDIENTE"
    End If
    If CStr(rea) <> "" And Not EsNum(rea) Then Err.Raise ERR_NEGOCIO, "motor", "REAL no numérico (" & CStr(rea) & ")"
    If CStr(er) <> "" And Not EsNum(er) Then Err.Raise ERR_NEGOCIO, "motor", "ERR no numérico (" & CStr(er) & ")"
    Set ws = Hoja("EST_DECISION")
    r = 0
    For q = 2 To UltFila("EST_DECISION")
        If CStr(ws.Cells(q, ColIdx("EST_DECISION", "EDE_REF")).Value) = CStr(ref) Then r = q
    Next q
    If r = 0 Then r = NuevaFila("EST_DECISION")
    cols = Array("EDE_REF", "EDE_OBJ", "EDE_PER", "EDE_PRED", "EDE_REAL", "EDE_ERR", "EDE_ESTADO", "EDE_REGLA")
    vals = Array(ref, obj, per, pred, rea, er, est, regla)
    For i = 0 To 7
        If Norm(ws.Cells(r, ColIdx("EST_DECISION", cols(i))).Value) <> Norm(vals(i)) Then SetCelda "EST_DECISION", r, ColIdx("EST_DECISION", cols(i)), vals(i)
    Next i
    gLogNum = 0
    Bitacora "@SEGUIM"
    Seguim = "OK"
    Exit Function
Fallo:
    Reversar
    Seguim = "ERROR: " & Err.Description
End Function
Public Function BajarNivel(ByVal cod As String, ByVal niv As Variant) As String
    ' I-2 (OT-098 V7): degradación AUT-01. Solo BAJA la autonomía de una entrada de PROPUESTA (número mayor = más control humano);
    ' subirla exige PROPONER y aprobación de otra persona. Espejo: Motor.nivel.
    Dim r As Long, ant As Long
    RecuperarPendientes
    uN = 0: cN = 0
    LimpiarCache
    On Error GoTo Fallo
    If Not Permiso("@NIVEL") Then Err.Raise ERR_NEGOCIO, "motor", Mensaje("MSG-SEG") & " (" & gPerfil & " -> @NIVEL)"
    If Not ExisteHoja("PROPUESTA") Then Err.Raise ERR_NEGOCIO, "motor", "la base no tiene PROPUESTA (falta la estructura de I-2)"
    r = FilaClave("PROPUESTA", cod)
    If r = 0 Then Err.Raise ERR_NEGOCIO, "motor", "PROPUESTA " & cod & " no existe"
    If Not EsNum(niv) Then Err.Raise ERR_NEGOCIO, "motor", "NIVEL no numérico (" & CStr(niv) & ")"
    If niv <> 0 And niv <> 1 And niv <> 2 Then Err.Raise ERR_NEGOCIO, "motor", "NIVEL fuera de dominio (0, 1, 2)"
    ant = CLng(Num(Hoja("PROPUESTA").Cells(r, ColIdx("PROPUESTA", "PRO_NIVEL")).Value))
    If CLng(niv) <= ant Then Err.Raise ERR_NEGOCIO, "motor", "@NIVEL solo baja la autonomía (" & ant & " -> " & CLng(niv) & " no permitido; use PROPONER)"
    SetCelda "PROPUESTA", r, ColIdx("PROPUESTA", "PRO_NIVEL"), CLng(niv)
    gLogNum = 0
    Bitacora "@NIVEL AUT-01"
    BajarNivel = "OK"
    Exit Function
Fallo:
    Reversar
    BajarNivel = "ERROR: " & Err.Description
End Function
Public Function InvProc(ByVal per As String, ByVal obj As String, ByVal ele As String, ByVal val As Variant, ByVal emp As String) As String
    ' V4.1 I-1 (OT-095): inventario final del cierre (K9). Escribe o reemplaza la fila (PER, OBJ, ELE, EMP) de INV_PROCESO.
    ' Autorizado por PERFIL_TRX; el periodo debe existir y estar abierto (A = en cierre); deja BITACORA. Espejo: Motor.invproc.
    Dim r As Long, q As Long, ws As Object, pe As Long
    RecuperarPendientes
    uN = 0: cN = 0
    LimpiarCache
    On Error GoTo Fallo
    If Not Permiso("@INVPROC") Then Err.Raise ERR_NEGOCIO, "motor", Mensaje("MSG-SEG") & " (" & gPerfil & " -> @INVPROC)"
    pe = 0
    For q = 2 To UltFila("PERIODO")
        If CStr(Hoja("PERIODO").Cells(q, ColIdx("PERIODO", "PER_COD")).Value) = per And CStr(Hoja("PERIODO").Cells(q, ColIdx("PERIODO", "PER_EMP")).Value) = emp Then pe = q
    Next q
    If pe = 0 Then Err.Raise ERR_NEGOCIO, "motor", "periodo " & per & " de " & emp & " no existe"
    If CStr(Hoja("PERIODO").Cells(pe, ColIdx("PERIODO", "PER_EST")).Value) <> "A" Then Err.Raise ERR_NEGOCIO, "motor", "periodo " & per & " de " & emp & " no está en cierre"
    If Not EsNum(val) Then Err.Raise ERR_NEGOCIO, "motor", "VAL no numérico (" & CStr(val) & ")"   ' LO-3: la trama ya llega como número (ParseValor)
    Set ws = Hoja("INV_PROCESO")
    r = 0
    For q = 2 To UltFila("INV_PROCESO")
        If CStr(ws.Cells(q, ColIdx("INV_PROCESO", "IPR_PER")).Value) = per And CStr(ws.Cells(q, ColIdx("INV_PROCESO", "IPR_OBJ")).Value) = obj _
           And CStr(ws.Cells(q, ColIdx("INV_PROCESO", "IPR_ELE")).Value) = ele And CStr(ws.Cells(q, ColIdx("INV_PROCESO", "IPR_EMP")).Value) = emp Then r = q
    Next q
    If r > 0 Then
        SetCelda "INV_PROCESO", r, ColIdx("INV_PROCESO", "IPR_VAL"), CDbl(val)
    Else
        r = NuevaFila("INV_PROCESO")
        SetCelda "INV_PROCESO", r, ColIdx("INV_PROCESO", "IPR_PER"), per
        SetCelda "INV_PROCESO", r, ColIdx("INV_PROCESO", "IPR_OBJ"), obj
        SetCelda "INV_PROCESO", r, ColIdx("INV_PROCESO", "IPR_VAL"), CDbl(val)
        SetCelda "INV_PROCESO", r, ColIdx("INV_PROCESO", "IPR_EMP"), emp
        SetCelda "INV_PROCESO", r, ColIdx("INV_PROCESO", "IPR_ELE"), ele
    End If
    gLogNum = 0
    Bitacora "@INVPROC"
    InvProc = "OK"
    Exit Function
Fallo:
    Reversar
    InvProc = "ERROR: " & Err.Description
End Function

Public Function ResolverCambio(ByVal numProp As Variant, ByVal dec As String, Optional ByVal desde As String = "", Optional ByVal motivo As String = "") As String
    ' EC-14: si la propuesta es parte de un paquete, el paquete completo se aprueba o se rechaza junto
    Dim p As Long, r As Long, partes() As String, j As Long, tabla As String, wc As Object, paq As String, q As Long
    RecuperarPendientes
    uN = 0: cN = 0
    LimpiarCache
    On Error GoTo Fallo
    If Not Permiso("APRUEBA-PARM") Then Err.Raise ERR_NEGOCIO, "motor", Mensaje("MSG-SEG") & " (" & gPerfil & " -> APRUEBA-PARM)"
    dec = UCase(dec)
    If dec <> "A" And dec <> "R" And dec <> "S" Then Err.Raise ERR_NEGOCIO, "motor", "decisión " & dec & " no válida (A, R o S)"
    If dec = "S" And Trim(motivo) = "" Then Err.Raise ERR_NEGOCIO, "motor", Mensaje("MSG-MOTIVO")   ' I-3 (L-8): posponer exige motivo
    Set wc = Hoja("PARAM_CAMBIO")
    p = FilaClave("PARAM_CAMBIO", numProp)
    If p = 0 Then Err.Raise ERR_NEGOCIO, "motor", Mensaje("MSG-PCA")
    If CStr(wc.Cells(p, 8).Value) <> "P" And CStr(wc.Cells(p, 8).Value) <> "S" Then Err.Raise ERR_NEGOCIO, "motor", Mensaje("MSG-PCA")
    paq = CStr(wc.Cells(p, 11).Value)
    For q = 2 To UltFila("PARAM_CAMBIO")
        If q = p Or (paq <> "" And CStr(wc.Cells(q, 11).Value) = paq And (CStr(wc.Cells(q, 8).Value) = "P" Or CStr(wc.Cells(q, 8).Value) = "S")) Then
            If CStr(wc.Cells(q, 7).Value) = gUsuario And Not EsNivel1(wc, q) Then Err.Raise ERR_NEGOCIO, "motor", Mensaje("MSG-AUTOAPRUEBA")
        End If
    Next q
    For q = 2 To UltFila("PARAM_CAMBIO")
        If q = p Or (paq <> "" And CStr(wc.Cells(q, 11).Value) = paq And (CStr(wc.Cells(q, 8).Value) = "P" Or CStr(wc.Cells(q, 8).Value) = "S")) Then
            If dec = "A" Then
                tabla = CStr(wc.Cells(q, 2).Value)
                If CStr(wc.Cells(q, 4).Value) = "(NUEVA)" Then
                    r = NuevaFila(tabla): partes = Split(CStr(wc.Cells(q, 6).Value), "|")
                    For j = 0 To UBound(partes)
                        SetCelda tabla, r, j + 1, ParseValor(partes(j))
                    Next j
                Else
                    r = FilaClave(tabla, wc.Cells(q, 3).Value)
                    SetCelda tabla, r, ColIdx(tabla, CStr(wc.Cells(q, 4).Value)), wc.Cells(q, 6).Value
                    ' V4.1 R-72: un cambio de PAR_VAL aprobado rige desde el periodo siguiente
                    If tabla = "PARAMETRO" And CStr(wc.Cells(q, 4).Value) = "PAR_VAL" And desde <> "" Then SetCelda tabla, r, ColIdx(tabla, "PAR_DESDE"), CLng(desde)
                End If
            End If
            wc.Cells(q, 8).Value = dec: wc.Cells(q, 9).Value = gUsuario
            If Trim(motivo) <> "" And TieneCol("PARAM_CAMBIO", "PCA_MOT_RES") Then wc.Cells(q, ColIdx("PARAM_CAMBIO", "PCA_MOT_RES")).Value = motivo   ' I-3 (H-3)
        End If
    Next q
    If dec = "A" Then
        gLogNum = 0
        Bitacora "APRUEBA-PARM"
    End If
    ResolverCambio = "OK"
    Exit Function
Fallo:
    Dim msg As String: msg = Err.Description
    On Error Resume Next
    Reversar
    ResolverCambio = "ERROR: " & msg
End Function
Private Function TrazaActiva() As Boolean
    Dim f As Variant
    If THas("TRAZA") Then
        If UCase(CStr(TGet("TRAZA"))) = "S" Then TrazaActiva = True: Exit Function
    End If
    On Error Resume Next
    f = Filas("PARAMETRO", "PAR_COD", "TRAZA", "")
    If Err.Number = 0 Then
        If f(0) > 0 Then TrazaActiva = (UCase(CStr(Celda("PARAMETRO", f(1), "PAR_VAL"))) = "S")
    End If
    Err.Clear
End Function
Private Sub Trazar(ByVal met As String, ByVal vr As String, ByVal v As Variant, ByVal det As String)
    Dim r As Long
    r = NuevaFila("TRAZA")
    SetCelda "TRAZA", r, ColIdx("TRAZA", "TRZ_NUM"), r - 1
    SetCelda "TRAZA", r, ColIdx("TRAZA", "TRZ_TRX"), TGet("TRX")
    SetCelda "TRAZA", r, ColIdx("TRAZA", "TRZ_MET"), met
    SetCelda "TRAZA", r, ColIdx("TRAZA", "TRZ_VAR"), vr
    SetCelda "TRAZA", r, ColIdx("TRAZA", "TRZ_VAL"), v
    SetCelda "TRAZA", r, ColIdx("TRAZA", "TRZ_DET"), det
    If THas("OBJ") Then SetCelda "TRAZA", r, ColIdx("TRAZA", "TRZ_OBJ"), TGet("OBJ")
End Sub
Public Function EsProtegido(ByVal tabla As String, ByVal fila As Long) As Boolean
    ' EC-15: un parámetro protegido solo se cambia por propuesta aprobada (aunque DOBLE_CONTROL = N)
    If tabla = "PARAMETRO" And fila > 0 Then EsProtegido = (CStr(Hoja("PARAMETRO").Cells(fila, ColIdx("PARAMETRO", "PAR_PROT")).Value) = "S")
End Function
Public Function MantenerFila(ByVal tabla As String, ByVal fila As Long, ByVal valores As Variant) As String
    ' MANT-PARM: crea (fila = 0) o modifica una fila de parámetros. Seguridad por perfil, bitácora y reversa.
    Dim j As Long, perm As Variant, ok As Boolean, i As Long, msgV As String
    uN = 0: cN = 0
    LimpiarCache
    On Error GoTo Fallo
    ok = Permiso("MANT-PARM")
    If Not ok Then Err.Raise ERR_NEGOCIO, "motor", Mensaje("MSG-SEG") & " (" & gPerfil & " -> MANT-PARM)"
    If Trim(CStr(valores(LBound(valores)))) = "" Then Err.Raise ERR_NEGOCIO, "motor", Mensaje("MSG-CLAVE")
    If EsProtegido(tabla, fila) Then Err.Raise ERR_NEGOCIO, "motor", Mensaje("MSG-PROTEGIDO")
    For j = 1 To NCols(tabla)
        msgV = ValidarDato(tabla, fila, CStr(Hoja(tabla).Cells(1, j).Value), valores(LBound(valores) + j - 1))
        If msgV <> "" Then Err.Raise ERR_NEGOCIO, "motor", msgV
    Next j
    If tabla = "USUARIO" Then                  ' E-098: la clave nunca se guarda en claro
        j = LBound(valores) + ColIdx("USUARIO", "USU_CLAVE") - 1
        If Left(CStr(valores(j)), 7) <> "SHA256:" And Left(CStr(valores(j)), 1) <> "(" Then valores(j) = ClaveCifrada(CStr(valores(LBound(valores))), CStr(valores(j)))
    End If
    If fila = 0 Then fila = NuevaFila(tabla)
    For j = 1 To NCols(tabla)
        SetCelda tabla, fila, j, valores(LBound(valores) + j - 1)
    Next j
    Bitacora "MANT-PARM"
    MantenerFila = "OK"
    Exit Function
Fallo:
    Dim msg As String: msg = Err.Description
    On Error Resume Next
    Reversar
    MantenerFila = "ERROR: " & msg
End Function
Private Sub TCopia(ByRef k() As String, ByRef v() As Variant, ByRef n As Long)
    Dim i As Long
    n = tN: ReDim k(0 To tN): ReDim v(0 To tN)
    For i = 1 To tN: k(i) = tK(i): v(i) = tV(i): Next i
End Sub
Private Sub TRestaura(ByRef k() As String, ByRef v() As Variant, ByVal n As Long)
    Dim i As Long
    TReset
    For i = 1 To n: TSet k(i), v(i): Next i
End Sub
Public Sub EjecutarOPN(ByVal op As String)
    Dim ms As Variant, i As Long
    gProf = gProf + 1                         ' al fallar no se decrementa: EjecutarTRX lo reinicia en cada transacción
    If gProf > PROF_MAX Then Err.Raise ERR_NEGOCIO, "motor", "profundidad máxima de operaciones excedida (posible ciclo): " & op
    ms = Filas("OME", "OME_OPN", op, "OME_SEC")
    If ms(0) = 0 Then Err.Raise ERR_NEGOCIO, "motor", "Operación sin métodos: " & op
    For i = 1 To ms(0)
        EjecutarMET CStr(Celda("OME", ms(i), "OME_MET"))
    Next i
    gProf = gProf - 1
End Sub
Private Function Referencia(ByVal x As String) As String
    ' OT-052: un nombre de operación o tabla con prefijo "VAR:" se toma de la variable en tiempo de ejecución
    If Left(x, 4) = "VAR:" Then Referencia = CStr(TGet(Mid(x, 5))) Else Referencia = x
End Function
Public Sub EjecutarMET(ByVal cod As String)
    Dim f As Variant, r As Long, tipo As String, tabla As String, subop As String, obl As String, orden As String, mca As Variant
    f = Filas("MET", "MET_COD", cod, "")
    If f(0) = 0 Then Err.Raise ERR_NEGOCIO, "motor", "Método no existe: " & cod
    r = f(1)
    tipo = CStr(Celda("MET", r, "MET_TIPO")): tabla = CStr(Celda("MET", r, "MET_TABLA"))
    subop = CStr(Celda("MET", r, "MET_SUB")): obl = CStr(Celda("MET", r, "MET_OBL")): orden = CStr(Celda("MET", r, "MET_ORD"))
    mca = Filas("MCA", "MCA_MET", cod, "MCA_SEC")
    Select Case tipo
        Case "LEER": MLeer cod, tabla, obl, orden, mca
        Case "CREAR": MCrear tabla, mca
        Case "ACTUALIZAR": MActualizar cod, tabla, obl, mca
        Case "ACUMULAR": MAcumular tabla, mca
        Case "FORMULA": MFormula cod
        Case "VALIDA": MValida cod
        Case "SI": If CondOK(cod) Then EjecutarOPN Referencia(subop)
        Case "PARACADA": MParaCada Referencia(tabla), subop, mca
        Case "ALGORITMO": MAlgoritmo
        Case Else: Err.Raise ERR_NEGOCIO, "motor", "Tipo de método desconocido: " & tipo
    End Select
End Sub
Private Function UmbralParametro(ByVal cod As String, ByVal emp As String) As Variant
    ' D1: valor de PARAMETRO para el codigo de umbral; primero el de la empresa, si no hay, el comun "*" (igual que el espejo)
    Dim f As Variant, i As Long, e As String
    UmbralParametro = ""
    f = Filas("PARAMETRO", "PAR_COD", cod, "")
    For i = 1 To f(0)
        e = CStr(Celda("PARAMETRO", f(i), "PAR_EMP"))
        If Norm(e) = Norm(emp) Then UmbralParametro = Celda("PARAMETRO", f(i), "PAR_VAL"): Exit Function
        If Norm(e) = "*" Then UmbralParametro = Celda("PARAMETRO", f(i), "PAR_VAL")
    Next i
End Function
Private Function Coincide(ByVal tabla As String, ByVal r As Long, ByVal mca As Variant, Optional ByVal comodin As Boolean = False) As Boolean
    ' D12 (Ola 1): con comodin, una clave *_EMP acepta la fila comun "*" (Buscar prueba primero sin comodin)
    Dim i As Long, rol As String, cel As Variant, v As Variant, c As String
    For i = 1 To mca(0)
        rol = CStr(Celda("MCA", mca(i), "MCA_ROL"))
        If rol = "K" Or rol = "H" Then
            c = CStr(Celda("MCA", mca(i), "MCA_COL"))
            cel = Celda(tabla, r, c)
            v = Valor(CStr(Celda("MCA", mca(i), "MCA_ORI")), Celda("MCA", mca(i), "MCA_VAL"))
            If rol = "K" And Norm(cel) <> Norm(v) Then
                If Not (comodin And Right(c, 4) = "_EMP" And Norm(cel) = "*") Then Coincide = False: Exit Function
            End If
            If rol = "H" And Num(cel) > Num(v) Then Coincide = False: Exit Function
        End If
    Next i
    Coincide = True
End Function
Private Function Buscar(ByVal tabla As String, ByVal mca As Variant, ByVal orden As String) As Long
    ' D12 (Ola 1): primero filas exactas; si no hay ninguna, se acepta la fila comun "*" en las claves *_EMP
    Buscar = Buscar1(tabla, mca, orden, False)
    If Buscar = 0 Then Buscar = Buscar1(tabla, mca, orden, True)
End Function
Private Function Buscar1(ByVal tabla As String, ByVal mca As Variant, ByVal orden As String, ByVal comodin As Boolean) As Long
    Dim r As Long, mejor As Long, desc As Boolean, oc As String
    If orden <> "" Then desc = (Left(orden, 1) = "-"): oc = Replace(orden, "-", "")
    For r = 2 To UltFila(tabla)
        If Coincide(tabla, r, mca, comodin) Then
            If orden = "" Then Buscar1 = r: Exit Function
            If mejor = 0 Then
                mejor = r
            ElseIf desc And Num(Celda(tabla, r, oc)) > Num(Celda(tabla, mejor, oc)) Then
                mejor = r
            ElseIf (Not desc) And Num(Celda(tabla, r, oc)) < Num(Celda(tabla, mejor, oc)) Then
                mejor = r
            End If
        End If
    Next r
    Buscar1 = mejor
End Function
Private Function Destino(ByVal v As String) As String
    ' OT-058 (E-200): destino de LEER. "VAR:x" o prefijo+"{VAR:x}" (MVIG_{VAR:EJE_ACTUAL}) se resuelve en ejecucion; el nombre construido
    ' debe empezar por "MVIG_" y no ser vacio. Sin esa forma, el nombre literal de siempre.
    Dim n As String, a As Long, b As Long
    If Left(v, 4) <> "VAR:" And InStr(v, "{VAR:") = 0 Then Destino = v: Exit Function
    If Left(v, 4) = "VAR:" Then
        n = CStr(TGet(Mid(v, 5)))
    Else
        n = v
        Do While InStr(n, "{VAR:") > 0
            a = InStr(n, "{VAR:"): b = InStr(a, n, "}")
            n = Left(n, a - 1) & CStr(TGet(Mid(n, a + 5, b - a - 5))) & Mid(n, b + 1)
        Loop
    End If
    If Trim(n) = "" Or (Left(n, 5) = "MVIG_" And Trim(Mid(n, 6)) = "") Then Err.Raise ERR_NEGOCIO, "motor", "Variable destino vacía: " & v
    If Left(n, 5) <> "MVIG_" Then Err.Raise ERR_NEGOCIO, "motor", "Variable destino no permitida (debe empezar por MVIG_): " & n
    Destino = n
End Function
Private Sub MLeer(ByVal cod As String, ByVal tabla As String, ByVal obl As String, ByVal orden As String, ByVal mca As Variant)
    Dim r As Long, i As Long
    r = Buscar(tabla, mca, orden)
    If r = 0 And obl = "S" Then Err.Raise ERR_NEGOCIO, "motor", "No existe en " & tabla & " (" & cod & ")"
    TSet "HALLADA", IIf(r = 0, "N", "S")      ' OT-056 (R3): hallada S/N, parte del modo de acceso de LEER
    For i = 1 To mca(0)
        If CStr(Celda("MCA", mca(i), "MCA_ROL")) = "V" Then
            If r = 0 Then
                TSet Destino(CStr(Celda("MCA", mca(i), "MCA_VAL"))), ""
            Else
                TSet Destino(CStr(Celda("MCA", mca(i), "MCA_VAL"))), Celda(tabla, r, CStr(Celda("MCA", mca(i), "MCA_COL")))
            End If
        End If
    Next i
End Sub
Private Sub MCrear(ByVal tabla As String, ByVal mca As Variant)
    Dim r As Long, i As Long, c As String, ori As String, v As Variant, mx As Double, k As Long
    r = NuevaFila(tabla)
    For i = 1 To mca(0)
        c = CStr(Celda("MCA", mca(i), "MCA_COL")): ori = CStr(Celda("MCA", mca(i), "MCA_ORI")): v = Celda("MCA", mca(i), "MCA_VAL")
        If ori = "SIS" And CStr(v) = "#SIG" Then
            mx = 0
            For k = 2 To r - 1
                If Num(Celda(tabla, k, c)) > mx Then mx = Num(Celda(tabla, k, c))
            Next k
            SetCelda tabla, r, ColIdx(tabla, c), mx + 1: TSet c, mx + 1
        Else
            SetCelda tabla, r, ColIdx(tabla, c), Valor(ori, v)
        End If
    Next i
End Sub
Private Sub MActualizar(ByVal cod As String, ByVal tabla As String, ByVal obl As String, ByVal mca As Variant)
    Dim r As Long, i As Long, c As String, ope As String, v As Variant, cc As Long, actual As Variant
    r = Buscar(tabla, mca, "")
    If r = 0 Then
        If obl = "S" Then Err.Raise ERR_NEGOCIO, "motor", "No existe la fila a actualizar en " & tabla & " (" & cod & ")"
        Exit Sub
    End If
    For i = 1 To mca(0)
        If CStr(Celda("MCA", mca(i), "MCA_ROL")) = "V" Then
            c = Plantilla(CStr(Celda("MCA", mca(i), "MCA_COL"))): cc = ColIdx(tabla, c)
            ope = CStr(Celda("MCA", mca(i), "MCA_OPE"))
            v = Valor(CStr(Celda("MCA", mca(i), "MCA_ORI")), Celda("MCA", mca(i), "MCA_VAL"))
            actual = Hoja(tabla).Cells(r, cc).Value
            Select Case ope
                Case "SUMA": SetCelda tabla, r, cc, Num(actual) + Num(v)
                Case "RESTA": SetCelda tabla, r, cc, Num(actual) - Num(v)
                Case Else: SetCelda tabla, r, cc, v
            End Select
        End If
    Next i
End Sub
Private Sub MAcumular(ByVal tabla As String, ByVal mca As Variant)
    ' OT-056: operador COMPUESTO, una sola entrada: LEER (no obligatorio, R1) -> FORMULA (viejo +/- dato; ASIGNA reemplaza
    ' sin convertir, R5; viejo = 0 si no hay fila) -> CREAR (claves; sumas en 0) y ACTUALIZAR con los valores ya calculados (R2).
    ' Variables locales con prefijo propio (R6): la trama no se toca. Igual que m_ACUMULAR de motor_espejo.py (P19).
    Dim acuFila As Long, acuHallada As Boolean, acuN As Long, acuCol() As Long, acuVal() As Variant
    Dim i As Long, j As Long, k As Long, cc As Long, ope As String, v As Variant, viejo As Variant
    acuFila = Buscar(tabla, mca, ""): acuHallada = (acuFila > 0)
    For i = 1 To mca(0)
        If CStr(Celda("MCA", mca(i), "MCA_ROL")) = "V" Then
            cc = ColIdx(tabla, Plantilla(CStr(Celda("MCA", mca(i), "MCA_COL"))))
            ope = CStr(Celda("MCA", mca(i), "MCA_OPE"))
            v = Valor(CStr(Celda("MCA", mca(i), "MCA_ORI")), Celda("MCA", mca(i), "MCA_VAL"))
            k = 0
            For j = 1 To acuN
                If acuCol(j) = cc Then k = j
            Next j
            If k > 0 Then
                viejo = acuVal(k)
            ElseIf acuHallada Then
                viejo = Hoja(tabla).Cells(acuFila, cc).Value
            ElseIf ope = "SUMA" Or ope = "RESTA" Then
                viejo = 0
            Else
                viejo = Empty
            End If
            If k = 0 Then acuN = acuN + 1: ReDim Preserve acuCol(1 To acuN): ReDim Preserve acuVal(1 To acuN): k = acuN
            acuCol(k) = cc
            Select Case ope
                Case "SUMA": acuVal(k) = Num(viejo) + Num(v)
                Case "RESTA": acuVal(k) = Num(viejo) - Num(v)
                Case Else: acuVal(k) = v
            End Select
        End If
    Next i
    If Not acuHallada Then
        acuFila = NuevaFila(tabla)
        For i = 1 To mca(0)
            cc = ColIdx(tabla, Plantilla(CStr(Celda("MCA", mca(i), "MCA_COL"))))
            If CStr(Celda("MCA", mca(i), "MCA_ROL")) = "K" Then
                SetCelda tabla, acuFila, cc, Valor(CStr(Celda("MCA", mca(i), "MCA_ORI")), Celda("MCA", mca(i), "MCA_VAL"))
            ElseIf CStr(Celda("MCA", mca(i), "MCA_OPE")) = "SUMA" Or CStr(Celda("MCA", mca(i), "MCA_OPE")) = "RESTA" Then
                SetCelda tabla, acuFila, cc, 0
            End If
        Next i
    End If
    For j = 1 To acuN
        SetCelda tabla, acuFila, acuCol(j), acuVal(j)
    Next j
End Sub
Private Function NumTexto(ByVal x As Double) As String
    ' OT-060: numero -> texto estable (igual que texto_num del espejo): 9 decimales, sin ceros finales, punto decimal, sin exponente
    Dim t As String, sepDec As String
    If Abs(x) >= 1000000000000000# Then Err.Raise ERR_NEGOCIO, "motor", "Número fuera de rango para CONCATENA"
    t = Format(x, "0.000000000"): sepDec = Mid(Format(1.5, "0.0"), 2, 1)
    If sepDec <> "." Then t = Replace(t, sepDec, ".")
    Do While Right(t, 1) = "0"
        t = Left(t, Len(t) - 1)
    Loop
    If Right(t, 1) = "." Then t = Left(t, Len(t) - 1)
    If t = "" Or t = "-0" Then t = "0"
    NumTexto = t
End Function
Private Function TextoValor(ByVal v As Variant) As String
    If IsEmpty(v) Then
        TextoValor = ""
    ElseIf EsNum(v) Then
        TextoValor = NumTexto(CDbl(v))
    Else
        TextoValor = CStr(v)
    End If
End Function
Private Sub MFormula(ByVal cod As String)
    Dim f As Variant, i As Long, op As String, vr As String, lit As Variant, acc As Double, x As Double, det As String
    Dim txt As String, esTxt As Boolean, ini As Boolean, tcad As String
    ini = True
    f = Filas("FRM", "FRM_MET", cod, "FRM_SEC")
    For i = 1 To f(0)
        op = CStr(Celda("FRM", f(i), "FRM_OPE")): vr = CStr(Celda("FRM", f(i), "FRM_VAR")): lit = Celda("FRM", f(i), "FRM_LIT")
        If op = "ASIGNA" Then
            If esTxt Then
                TSet vr, txt
            Else
                TSet vr, acc
            End If
            If gTraza Then
                If esTxt Then
                    Trazar cod, vr, txt, det
                Else
                    Trazar cod, vr, acc, det
                End If
            End If
            det = ""
        ElseIf op = "CONCATENA" Then
            If Not esTxt Then
                If ini Then txt = "" Else txt = NumTexto(acc)
                esTxt = True
            End If
            If vr <> "" Then tcad = TextoValor(TGet(vr)) Else tcad = TextoValor(lit)
            If vr <> "" And txt <> "" Then txt = txt & TextoValor(lit)
            txt = txt & tcad: ini = False
            If gTraza Then det = det & "CONCATENA " & IIf(vr <> "", vr & "=", "") & tcad & "; "
        Else
            If esTxt And op <> "INICIA" Then Err.Raise ERR_NEGOCIO, "motor", "Operación " & op & " sobre texto acumulado en " & cod
            If vr <> "" Then x = Num(TGet(vr)) Else x = Num(lit)
            If gTraza Then det = det & op & " " & IIf(vr <> "", vr & "=", "") & CStr(x) & "; "
            ini = False
            Select Case op
                Case "INICIA": acc = x: esTxt = False
                Case "SUMA": acc = acc + x
                Case "RESTA": acc = acc - x
                Case "MULT": acc = acc * x
                Case "DIVIDE"
                    If x = 0 Then Err.Raise ERR_NEGOCIO, "motor", "División entre cero en " & cod
                    acc = acc / x
                Case "MAX": If x > acc Then acc = x
                Case "MIN": If x < acc Then acc = x
                Case "RED": acc = Redondear(acc, CLng(Num(lit)))
                Case Else: Err.Raise ERR_NEGOCIO, "motor", "Operador desconocido: " & op
            End Select
        End If
    Next i
End Sub
Private Function Compara(ByVal a As Variant, ByVal b As Variant) As Integer
    Dim x As Double, y As Double, sa As String, sb As String
    If (EsNum(a) Or ParesNum(a)) And (EsNum(b) Or ParesNum(b)) Then
        x = Num(a): y = Num(b)
        If x > y Then Compara = 1 Else If x < y Then Compara = -1 Else Compara = 0
    Else
        sa = Norm(a): sb = Norm(b)
        If sa > sb Then Compara = 1 Else If sa < sb Then Compara = -1 Else Compara = 0
    End If
End Function
Private Function ParesNum(ByVal v As Variant) As Boolean
    ParesNum = EsNum(ParseValor(CStr(v))) And Trim(CStr(v)) <> ""
End Function
Private Function EvalCond(ByVal r As Long) As Boolean
    Dim a As Variant, b As Variant, ope As String, k As Integer
    a = TGet(CStr(Celda("CND", r, "CND_VAR")))
    If CStr(Celda("CND", r, "CND_VAR2")) <> "" Then b = TGet(CStr(Celda("CND", r, "CND_VAR2"))) Else b = Celda("CND", r, "CND_LIT")
    ope = CStr(Celda("CND", r, "CND_OPE")): k = Compara(a, b)
    Select Case ope
        Case "EQ": EvalCond = (k = 0)
        Case "NE": EvalCond = (k <> 0)
        Case "GT": EvalCond = (k > 0)
        Case "GE": EvalCond = (k >= 0)
        Case "LT": EvalCond = (k < 0)
        Case "LE": EvalCond = (k <= 0)
        Case Else: Err.Raise ERR_NEGOCIO, "motor", "Operador lógico desconocido: " & ope
    End Select
End Function
Private Function CondOK(ByVal cod As String) As Boolean
    Dim f As Variant, i As Long
    f = Filas("CND", "CND_MET", cod, "")
    CondOK = True
    For i = 1 To f(0)
        If Not EvalCond(f(i)) Then CondOK = False: Exit Function
    Next i
End Function
Private Sub MValida(ByVal cod As String)
    Dim f As Variant, i As Long
    f = Filas("CND", "CND_MET", cod, "")
    For i = 1 To f(0)
        If Not EvalCond(f(i)) Then Err.Raise ERR_NEGOCIO, "motor", Mensaje(CStr(Celda("CND", f(i), "CND_MSG")))
    Next i
End Sub
Private Sub MParaCada(ByVal tabla As String, ByVal subop As String, ByVal mca As Variant)
    Dim filasOk() As Long, n As Long, r As Long, i As Long, j As Long, nc As Long, hojaX As Object, existe As Boolean
    For Each hojaX In ThisWorkbook.Worksheets
        If hojaX.Name = tabla Then existe = True
    Next hojaX
    If Not existe Then Err.Raise ERR_NEGOCIO, "motor", "Tabla no existe: " & tabla
    ReDim filasOk(0 To 0)
    For r = 2 To UltFila(tabla)
        If Coincide(tabla, r, mca) Then n = n + 1: ReDim Preserve filasOk(0 To n): filasOk(n) = r
    Next r
    If n = 0 Then                                     ' D12: sin filas exactas, se aceptan las comunes "*" (igual que el espejo)
        For r = 2 To UltFila(tabla)
            If Coincide(tabla, r, mca, True) Then n = n + 1: ReDim Preserve filasOk(0 To n): filasOk(n) = r
        Next r
    End If
    nc = NCols(tabla)
    For i = 1 To n
        For j = 1 To nc
            TSet CStr(Hoja(tabla).Cells(1, j).Value), Hoja(tabla).Cells(filasOk(i), j).Value
        Next j
        EjecutarOPN Referencia(subop)
    Next i
End Sub
Private Function ColRol(ByVal mca As Variant, ByVal rol As String, ByVal n As Long) As String
    ' n-ésima columna (1, 2, ...) de la MCA con ese rol
    Dim i As Long, c As Long
    For i = 1 To mca(0)
        If CStr(Celda("MCA", mca(i), "MCA_ROL")) = rol Then
            c = c + 1
            If c = n Then ColRol = CStr(Celda("MCA", mca(i), "MCA_COL")): Exit Function
        End If
    Next i
    ColRol = ""
End Function
Private Function Aleatorio(ByRef semilla As Double) As Double
    ' Park-Miller: x = 16807 x mod (2^31 - 1). Exacto en Double; idéntico al espejo en Python.
    Dim x As Double, m As Double
    m = 2147483647#
    x = 16807# * semilla
    x = x - Int(x / m) * m
    If x < 0 Then x = x + m
    If x >= m Then x = x - m
    semilla = x
    Aleatorio = x / m
End Function
Private Function Triangular(ByVal v As Double, ByVal a As Double, ByVal m As Double, ByVal b As Double) As Double
    If b <= a Then Triangular = a: Exit Function
    If v < (m - a) / (b - a) Then
        Triangular = a + Sqr(v * (b - a) * (m - a))
    Else
        Triangular = b - Sqr((1 - v) * (b - a) * (b - m))
    End If
End Function
Private Sub Ordenar(ByRef a() As Double, ByVal lo As Long, ByVal hi As Long)
    Dim i As Long, j As Long, p As Double, t As Double
    i = lo: j = hi: p = a((lo + hi) \ 2)
    Do While i <= j
        Do While a(i) < p: i = i + 1: Loop
        Do While a(j) > p: j = j - 1: Loop
        If i <= j Then t = a(i): a(i) = a(j): a(j) = t: i = i + 1: j = j - 1
    Loop
    If lo < j Then Ordenar a, lo, j
    If i < hi Then Ordenar a, i, hi
End Sub
Private Sub MAlgoritmo()
    Dim alg As String, p As Variant, i As Long
    alg = CStr(TGet("ALG"))
    p = Filas("PAL", "PAL_ALG", alg, "PAL_SEC")
    If p(0) = 0 Then Err.Raise ERR_NEGOCIO, "motor", "Algoritmo sin pasos: " & alg
    For i = 1 To p(0)
        EjecutarMET CStr(Celda("PAL", p(i), "PAL_MET"))
    Next i
End Sub

' ---------- SHA-256 (FIPS 180-4) para las claves de usuario (E-098). Palabras de 32 bits como Double en [0, 2^32):
' AND/OR/XOR por mitades de 16 bits (Long seguro), desplazamientos por división exacta. Idéntico a hashlib.sha256 (UTF-8).
Private Function ShU(ByVal x As Double) As Double
    ShU = x - Int(x / 4294967296#) * 4294967296#
End Function
Private Function ShBit(ByVal a As Double, ByVal b As Double, ByVal op As Integer) As Double
    Dim ah As Long, al As Long, bh As Long, bl As Long, rh As Long, rl As Long
    ah = Int(a / 65536#): al = a - ah * 65536#: bh = Int(b / 65536#): bl = b - bh * 65536#
    If op = 1 Then
        rh = ah And bh: rl = al And bl
    ElseIf op = 2 Then
        rh = ah Or bh: rl = al Or bl
    Else
        rh = ah Xor bh: rl = al Xor bl
    End If
    ShBit = CDbl(rh) * 65536# + rl
End Function
Private Function ShR(ByVal a As Double, ByVal n As Integer) As Double
    ShR = Int(a / 2 ^ n)
End Function
Private Function ShRot(ByVal a As Double, ByVal n As Integer) As Double
    Dim alto As Double
    alto = Int(a / 2 ^ n)
    ShRot = alto + (a - alto * 2 ^ n) * 2 ^ (32 - n)
End Function
Private Function ShUtf8(ByVal s As String) As Variant
    Dim b() As Long, k As Long, i As Long, c As Long
    ReDim b(0 To Len(s) * 3 + 72): k = 0
    For i = 1 To Len(s)
        c = AscW(Mid(s, i, 1)): If c < 0 Then c = c + 65536
        If c < 128 Then
            b(k) = c: k = k + 1
        ElseIf c < 2048 Then
            b(k) = 192 + Int(c / 64): b(k + 1) = 128 + (c Mod 64): k = k + 2
        Else
            b(k) = 224 + Int(c / 4096): b(k + 1) = 128 + (Int(c / 64) Mod 64): b(k + 2) = 128 + (c Mod 64): k = k + 3
        End If
    Next i
    ShUtf8 = Array(b, k)
End Function
Public Function Sha256Hex(ByVal s As String) As String
    Dim kk As Variant, hh As Variant, u As Variant, b() As Long, n As Long, total As Long, i As Long, j As Long, t As Long
    Dim w(0 To 63) As Double, h(0 To 7) As Double, a As Double, bb As Double, c As Double, d As Double, e As Double, f As Double, g As Double, hx As Double
    Dim s0 As Double, s1 As Double, ch As Double, mj As Double, t1 As Double, t2 As Double, bits As Double, res As String
    kk = Array(1116352408#, 1899447441#, 3049323471#, 3921009573#, 961987163#, 1508970993#, 2453635748#, 2870763221#, 3624381080#, 310598401#, 607225278#, 1426881987#, 1925078388#, 2162078206#, 2614888103#, 3248222580#, 3835390401#, 4022224774#, 264347078#, 604807628#, 770255983#, 1249150122#, 1555081692#, 1996064986#, 2554220882#, 2821834349#, 2952996808#, 3210313671#, 3336571891#, 3584528711#, 113926993#, 338241895#, 666307205#, 773529912#, 1294757372#, 1396182291#, 1695183700#, 1986661051#, 2177026350#, 2456956037#, 2730485921#, 2820302411#, 3259730800#, 3345764771#, 3516065817#, 3600352804#, 4094571909#, 275423344#, 430227734#, 506948616#, 659060556#, 883997877#, 958139571#, 1322822218#, 1537002063#, 1747873779#, 1955562222#, 2024104815#, 2227730452#, 2361852424#, 2428436474#, 2756734187#, 3204031479#, 3329325298#)
    hh = Array(1779033703#, 3144134277#, 1013904242#, 2773480762#, 1359893119#, 2600822924#, 528734635#, 1541459225#)
    For i = 0 To 7: h(i) = hh(i): Next i
    u = ShUtf8(s): b = u(0): n = u(1)
    total = (Int((n + 8) / 64) + 1) * 64
    ReDim Preserve b(0 To total - 1)
    For i = n To total - 1: b(i) = 0: Next i
    b(n) = 128: bits = CDbl(n) * 8
    For i = 0 To 7
        b(total - 1 - i) = bits - Int(bits / 256) * 256: bits = Int(bits / 256)
    Next i
    For j = 0 To total - 1 Step 64
        For t = 0 To 15
            w(t) = ((CDbl(b(j + 4 * t)) * 256 + b(j + 4 * t + 1)) * 256 + b(j + 4 * t + 2)) * 256 + b(j + 4 * t + 3)
        Next t
        For t = 16 To 63
            s0 = ShBit(ShBit(ShRot(w(t - 15), 7), ShRot(w(t - 15), 18), 3), ShR(w(t - 15), 3), 3)
            s1 = ShBit(ShBit(ShRot(w(t - 2), 17), ShRot(w(t - 2), 19), 3), ShR(w(t - 2), 10), 3)
            w(t) = ShU(w(t - 16) + s0 + w(t - 7) + s1)
        Next t
        a = h(0): bb = h(1): c = h(2): d = h(3): e = h(4): f = h(5): g = h(6): hx = h(7)
        For t = 0 To 63
            s1 = ShBit(ShBit(ShRot(e, 6), ShRot(e, 11), 3), ShRot(e, 25), 3)
            ch = ShBit(ShBit(e, f, 1), ShBit(4294967295# - e, g, 1), 3)
            t1 = ShU(hx + s1 + ch + kk(t) + w(t))
            s0 = ShBit(ShBit(ShRot(a, 2), ShRot(a, 13), 3), ShRot(a, 22), 3)
            mj = ShBit(ShBit(ShBit(a, bb, 1), ShBit(a, c, 1), 3), ShBit(bb, c, 1), 3)
            t2 = ShU(s0 + mj)
            hx = g: g = f: f = e: e = ShU(d + t1): d = c: c = bb: bb = a: a = ShU(t1 + t2)
        Next t
        h(0) = ShU(h(0) + a): h(1) = ShU(h(1) + bb): h(2) = ShU(h(2) + c): h(3) = ShU(h(3) + d)
        h(4) = ShU(h(4) + e): h(5) = ShU(h(5) + f): h(6) = ShU(h(6) + g): h(7) = ShU(h(7) + hx)
    Next j
    For i = 0 To 7
        res = res & Right("0000" & LCase(Hex(Int(h(i) / 65536#))), 4) & Right("0000" & LCase(Hex(h(i) - Int(h(i) / 65536#) * 65536#)), 4)
    Next i
    Sha256Hex = res
End Function
Public Function ClaveCifrada(ByVal u As String, ByVal clave As String) As String
    ' Lo que se guarda en USUARIO.USU_CLAVE: nunca la clave, solo su huella (usuario:clave)
    ClaveCifrada = "SHA256:" & Sha256Hex(UCase(u) & ":" & clave)
End Function
